import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/assessment_header.dart';
import './widgets/comments_section.dart';
import './widgets/evidence_capture_section.dart';
import './widgets/quick_scoring_buttons.dart';
import './widgets/rubric_scoring_section.dart';
import './widgets/student_info_card.dart';
import './widgets/student_list_sidebar.dart';
import 'widgets/assessment_header.dart';
import 'widgets/comments_section.dart';
import 'widgets/evidence_capture_section.dart';
import 'widgets/quick_scoring_buttons.dart';
import 'widgets/rubric_scoring_section.dart';
import 'widgets/student_info_card.dart';
import 'widgets/student_list_sidebar.dart';

class InstructorAssessmentInterface extends StatefulWidget {
  const InstructorAssessmentInterface({super.key});

  @override
  State<InstructorAssessmentInterface> createState() =>
      _InstructorAssessmentInterfaceState();
}

class _InstructorAssessmentInterfaceState
    extends State<InstructorAssessmentInterface> with TickerProviderStateMixin {
  // Assessment session data
  String _currentSkill = "Sepakan Leret";
  Duration _sessionDuration = const Duration(minutes: 15, seconds: 30);
  bool _isTimerRunning = true;
  late Timer _timer;

  // Student data
  Map<String, dynamic>? _selectedStudent;
  final List<Map<String, dynamic>> _students = [
    {
      "studentId": "A20EC0001",
      "name": "Ahmad Faiz bin Abdullah",
      "class": "MPU3421-01",
      "group": "Kumpulan A",
      "photo":
          "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400",
      "assessmentStatus": "in_progress",
    },
    {
      "studentId": "A20EC0002",
      "name": "Siti Nurhaliza binti Hassan",
      "class": "MPU3421-01",
      "group": "Kumpulan A",
      "photo":
          "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400",
      "assessmentStatus": "completed",
    },
    {
      "studentId": "A20EC0003",
      "name": "Muhammad Aidil bin Razak",
      "class": "MPU3421-01",
      "group": "Kumpulan B",
      "photo":
          "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400",
      "assessmentStatus": "pending",
    },
    {
      "studentId": "A20EC0004",
      "name": "Nurul Aina binti Ibrahim",
      "class": "MPU3421-02",
      "group": "Kumpulan B",
      "photo":
          "https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=400",
      "assessmentStatus": "pending",
    },
    {
      "studentId": "A20EC0005",
      "name": "Khairul Anwar bin Mohamed",
      "class": "MPU3421-02",
      "group": "Kumpulan C",
      "photo":
          "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400",
      "assessmentStatus": "completed",
    },
  ];

  // Assessment data
  int? _selectedScore;
  String _comments = "";
  List<XFile> _capturedImages = [];
  bool _isSidebarVisible = false;
  bool _isDraftSaved = false;

  // Controllers
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _initializeData();
    _startTimer();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _timer.cancel();
    _tabController.dispose();
    super.dispose();
  }

  void _initializeData() {
    _selectedStudent = _students.first;
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_isTimerRunning && mounted) {
        setState(() {
          _sessionDuration = Duration(seconds: _sessionDuration.inSeconds + 1);
        });
      }
    });
  }

  void _toggleTimer() {
    setState(() {
      _isTimerRunning = !_isTimerRunning;
    });
    HapticFeedback.lightImpact();
  }

  void _onScoreSelected(int score) {
    setState(() {
      _selectedScore = score;
      _isDraftSaved = false;
    });
  }

  void _onCommentsChanged(String comments) {
    setState(() {
      _comments = comments;
      _isDraftSaved = false;
    });
  }

  void _onImageCaptured(XFile image) {
    setState(() {
      _capturedImages.add(image);
      _isDraftSaved = false;
    });
  }

  void _onImageRemoved(XFile image) {
    setState(() {
      _capturedImages.remove(image);
      _isDraftSaved = false;
    });
  }

  void _onStudentSelected(Map<String, dynamic> student) {
    setState(() {
      _selectedStudent = student;
      // Reset assessment data for new student
      _selectedScore = null;
      _comments = "";
      _capturedImages.clear();
      _isDraftSaved = false;
    });
  }

  void _toggleSidebar() {
    setState(() {
      _isSidebarVisible = !_isSidebarVisible;
    });
    HapticFeedback.selectionClick();
  }

  void _saveDraft() async {
    // Simulate saving draft
    HapticFeedback.mediumImpact();

    setState(() {
      _isDraftSaved = true;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'save',
              color: AppTheme.lightTheme.colorScheme.onInverseSurface,
              size: 5.w,
            ),
            SizedBox(width: 3.w),
            const Text("Draft penilaian telah disimpan"),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.inverseSurface,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _submitAssessment() async {
    if (_selectedScore == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              CustomIconWidget(
                iconName: 'warning',
                color: AppTheme.lightTheme.colorScheme.onError,
                size: 5.w,
              ),
              SizedBox(width: 3.w),
              const Text("Sila pilih skor sebelum menghantar penilaian"),
            ],
          ),
        ),
      );
      return;
    }

    // Show confirmation dialog
    final confirmed = await _showSubmitConfirmation();
    if (!confirmed) return;

    // Simulate submission
    HapticFeedback.heavyImpact();

    // Update student status
    if (_selectedStudent != null) {
      setState(() {
        _selectedStudent!["assessmentStatus"] = "completed";
      });
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.lightTheme.colorScheme.onInverseSurface,
              size: 5.w,
            ),
            SizedBox(width: 3.w),
            const Text("Penilaian telah dihantar berjaya"),
          ],
        ),
        backgroundColor: AppTheme.successLight,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );

    // Reset for next assessment
    _resetAssessment();
  }

  Future<bool> _showSubmitConfirmation() async {
    return await showDialog<bool>(
          context: context,
          builder: (context) {
            final theme = Theme.of(context);
            final colorScheme = theme.colorScheme;

            return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              title: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'send',
                    color: colorScheme.primary,
                    size: 6.w,
                  ),
                  SizedBox(width: 3.w),
                  const Text("Hantar Penilaian"),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Adakah anda pasti untuk menghantar penilaian ini?",
                    style: theme.textTheme.bodyMedium,
                  ),
                  SizedBox(height: 2.h),
                  Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: colorScheme.surfaceContainerHighest
                          .withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Pelajar: ${_selectedStudent?["name"] ?? ""}"),
                        Text("Kemahiran: $_currentSkill"),
                        Text("Skor: ${_selectedScore ?? "Tidak dipilih"}"),
                        Text("Gambar: ${_capturedImages.length} fail"),
                      ],
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text("Batal"),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text("Hantar"),
                ),
              ],
            );
          },
        ) ??
        false;
  }

  void _resetAssessment() {
    setState(() {
      _selectedScore = null;
      _comments = "";
      _capturedImages.clear();
      _isDraftSaved = false;
    });
  }

  void _cancelAssessment() {
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomInstructorAppBar(title: "Penilaian Kemahiran"),
      body: Stack(
        children: [
          _buildMainContent(),
          StudentListSidebar(
            students: _students,
            selectedStudent: _selectedStudent,
            onStudentSelected: _onStudentSelected,
            isVisible: _isSidebarVisible,
            onClose: () => setState(() => _isSidebarVisible = false),
          ),
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildActionBar(),
          const CustomInstructorBottomBar(currentIndex: 1),
        ],
      ),
      floatingActionButton: _buildStudentListFAB(),
    );
  }

  Widget _buildMainContent() {
    return SingleChildScrollView(
      child: Column(
        children: [
          AssessmentHeader(
            currentSkill: _currentSkill,
            sessionDuration: _sessionDuration,
            isTimerRunning: _isTimerRunning,
            onTimerToggle: _toggleTimer,
          ),
          if (_selectedStudent != null)
            StudentInfoCard(studentData: _selectedStudent!),
          QuickScoringButtons(
            selectedScore: _selectedScore,
            onScoreSelected: _onScoreSelected,
          ),
          RubricScoringSection(
            currentSkill: _currentSkill,
            selectedScore: _selectedScore,
            onScoreSelected: _onScoreSelected,
          ),
          EvidenceCaptureSection(
            capturedImages: _capturedImages,
            onImageCaptured: _onImageCaptured,
            onImageRemoved: _onImageRemoved,
          ),
          CommentsSection(
            comments: _comments,
            onCommentsChanged: _onCommentsChanged,
          ),
          SizedBox(height: 20.h), // Space for action bar
        ],
      ),
    );
  }

  Widget _buildActionBar() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: colorScheme.outline.withValues(alpha: 0.2),
            width: 1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _cancelAssessment,
                style: OutlinedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                  side: BorderSide(color: colorScheme.error),
                  foregroundColor: colorScheme.error,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: 'cancel',
                      color: colorScheme.error,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    const Text("Batal"),
                  ],
                ),
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: OutlinedButton(
                onPressed: _saveDraft,
                style: OutlinedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                  backgroundColor: _isDraftSaved
                      ? colorScheme.surfaceContainerHighest
                      : null,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: _isDraftSaved ? 'check' : 'save',
                      color: _isDraftSaved
                          ? colorScheme.primary
                          : colorScheme.onSurface,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    Text(_isDraftSaved ? "Disimpan" : "Simpan Draft"),
                  ],
                ),
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              flex: 2,
              child: ElevatedButton(
                onPressed: _submitAssessment,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                  backgroundColor: colorScheme.primary,
                  foregroundColor: colorScheme.onPrimary,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: 'send',
                      color: colorScheme.onPrimary,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    const Text("Hantar Penilaian"),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStudentListFAB() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return FloatingActionButton(
      onPressed: _toggleSidebar,
      backgroundColor: colorScheme.primary,
      foregroundColor: colorScheme.onPrimary,
      child: CustomIconWidget(
        iconName: 'group',
        color: colorScheme.onPrimary,
        size: 6.w,
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/notification_banner.dart';
import './widgets/progress_overview_card.dart';
import './widgets/quick_actions_section.dart';
import './widgets/recent_assessments_card.dart';
import './widgets/skill_categories_section.dart';
import './widgets/student_header.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard>
    with TickerProviderStateMixin {
  int _currentBottomNavIndex = 0;
  bool _isRefreshing = false;
  bool _isOffline = false;
  Map<String, dynamic>? _currentNotification;

  // Mock student data
  final Map<String, dynamic> _studentData = {
    "name": "Ahmad Faiz bin Abdullah",
    "studentId": "2021123456",
    "className": "MPU3421-01",
    "groupName": "Kumpulan A",
    "profileImage":
        "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400",
  };

  // Mock assessment data
  final List<Map<String, dynamic>> _recentAssessments = [
    {
      "id": 1,
      "title": "Penilaian Sepakan Leret",
      "description": "Teknik sepakan dari sisi untuk menghantar bola",
      "date": "15/08/2025",
      "status": "upcoming",
      "type": "practical",
    },
    {
      "id": 2,
      "title": "Simulasi Latihan Individu",
      "description": "Perancangan dan pelaksanaan latihan peribadi",
      "date": "10/08/2025",
      "status": "completed",
      "score": 85,
      "type": "simulation",
    },
    {
      "id": 3,
      "title": "Penilaian Hantaran Pendek",
      "description": "Ketepatan dan kelajuan hantaran jarak dekat",
      "date": "08/08/2025",
      "status": "pending",
      "type": "practical",
    },
  ];

  // Mock skill categories data
  final List<Map<String, dynamic>> _skillCategories = [
    {
      "id": 1,
      "name": "Sepakan Leret",
      "description": "Teknik sepakan dari sisi",
      "level": 3,
      "icon": "sports_soccer",
      "progress": 0.6,
    },
    {
      "id": 2,
      "name": "Hantaran Pendek",
      "description": "Ketepatan hantaran jarak dekat",
      "level": 4,
      "icon": "my_location",
      "progress": 0.8,
    },
    {
      "id": 3,
      "name": "Menjaring",
      "description": "Kemahiran menjaringkan gol",
      "level": 2,
      "icon": "gps_fixed",
      "progress": 0.4,
    },
    {
      "id": 4,
      "name": "Menjaga Gol",
      "description": "Teknik penjaga gol",
      "level": 3,
      "icon": "shield",
      "progress": 0.6,
    },
    {
      "id": 5,
      "name": "Undang-Undang",
      "description": "Pengetahuan peraturan futsal",
      "level": 5,
      "icon": "menu_book",
      "progress": 1.0,
    },
    {
      "id": 6,
      "name": "Teknik",
      "description": "Kemahiran teknikal am",
      "level": 3,
      "icon": "precision_manufacturing",
      "progress": 0.6,
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeData();
    _checkNotifications();
  }

  void _initializeData() {
    // Simulate checking offline status
    setState(() {
      _isOffline = false; // In real app, check actual connectivity
    });
  }

  void _checkNotifications() {
    // Simulate checking for notifications
    final hasUpcomingAssessment = _recentAssessments.any(
      (assessment) => assessment['status'] == 'upcoming',
    );

    if (hasUpcomingAssessment) {
      setState(() {
        _currentNotification = {
          "type": "assessment",
          "title": "Penilaian Akan Datang",
          "message":
              "Anda mempunyai penilaian yang akan datang. Sila bersedia!",
          "isUrgent": true,
        };
      });
    }
  }

  Future<void> _handleRefresh() async {
    if (_isRefreshing) return;

    setState(() {
      _isRefreshing = true;
    });

    // Haptic feedback for pull-to-refresh
    HapticFeedback.mediumImpact();

    // Simulate data refresh
    await Future.delayed(const Duration(seconds: 2));

    // Simulate sync completion
    setState(() {
      _isRefreshing = false;
      _isOffline = false;
    });

    // Show success feedback
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Data telah dikemas kini'),
          backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _onBottomNavTap(int index) {
    if (index == _currentBottomNavIndex) return;

    setState(() {
      _currentBottomNavIndex = index;
    });

    // Navigate based on index
    switch (index) {
      case 0:
        // Already on dashboard
        break;
      case 1:
        Navigator.pushNamed(context, '/skill-assessment-detail');
        break;
      case 2:
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Ciri chat akan datang tidak lama lagi')),
        );
        break;
      case 3:
        Navigator.pushNamed(context, '/student-profile');
        break;
    }
  }

  void _dismissNotification() {
    setState(() {
      _currentNotification = null;
    });
  }

  void _onNotificationTap() {
    Navigator.pushNamed(context, '/skill-assessment-detail');
  }

  void _showAIChat() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: 80.h,
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 1.h),
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'smart_toy',
                        color: AppTheme.lightTheme.colorScheme.tertiary,
                        size: 24,
                      ),
                      SizedBox(width: 3.w),
                      Text(
                        'AI Q&A Assistant',
                        style:
                            AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: CustomIconWidget(
                      iconName: 'close',
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      size: 24,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'smart_toy',
                        color: AppTheme.lightTheme.colorScheme.tertiary,
                        size: 64,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'AI Q&A Assistant',
                        style:
                            AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        'Tanya apa-apa soalan berkaitan kursus futsal dan dapatkan jawapan pantas dari AI!',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 3.h),
                      Text(
                        'Ciri ini akan datang tidak lama lagi',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.tertiary,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  double get _overallProgress {
    final practicalProgress = _skillCategories
            .map((skill) => skill['progress'] as double)
            .reduce((a, b) => a + b) /
        _skillCategories.length;
    const simulationProgress = 0.7; // Mock simulation progress
    return (practicalProgress * 0.6) + (simulationProgress * 0.4);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        color: AppTheme.lightTheme.colorScheme.primary,
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: StudentHeader(studentData: _studentData),
            ),
            if (_isOffline)
              SliverToBoxAdapter(
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'wifi_off',
                        color: Colors.orange,
                        size: 20,
                      ),
                      SizedBox(width: 3.w),
                      Expanded(
                        child: Text(
                          'Mod luar talian - Data mungkin tidak terkini',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: Colors.orange,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            if (_currentNotification != null)
              SliverToBoxAdapter(
                child: NotificationBanner(
                  notification: _currentNotification,
                  onDismiss: _dismissNotification,
                  onTap: _onNotificationTap,
                ),
              ),
            SliverToBoxAdapter(
              child: ProgressOverviewCard(
                overallProgress: _overallProgress,
                practicalSkillsProgress: _skillCategories
                        .map((skill) => skill['progress'] as double)
                        .reduce((a, b) => a + b) /
                    _skillCategories.length,
                trainingSimulationProgress: 0.7,
              ),
            ),
            SliverToBoxAdapter(
              child: RecentAssessmentsCard(
                assessments: _recentAssessments,
                onViewAll: () {
                  Navigator.pushNamed(context, '/skill-assessment-detail');
                },
              ),
            ),
            const SliverToBoxAdapter(
              child: QuickActionsSection(),
            ),
            SliverToBoxAdapter(
              child: SkillCategoriesSection(
                skillCategories: _skillCategories,
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(height: 10.h),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAIChat,
        backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
        child: CustomIconWidget(
          iconName: 'smart_toy',
          color: AppTheme.lightTheme.colorScheme.onTertiary,
          size: 28,
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          boxShadow: [
            BoxShadow(
              color:
                  AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          child: Container(
            height: 72,
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildBottomNavItem(0, 'dashboard', 'Dashboard'),
                _buildBottomNavItem(1, 'assignment', 'Penilaian'),
                _buildBottomNavItem(2, 'chat', 'Chat'),
                _buildBottomNavItem(3, 'person', 'Profil'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNavItem(int index, String iconName, String label) {
    final isSelected = index == _currentBottomNavIndex;
    final color = isSelected
        ? AppTheme.lightTheme.colorScheme.primary
        : AppTheme.lightTheme.colorScheme.onSurfaceVariant;

    return Expanded(
      child: InkWell(
        onTap: () => _onBottomNavTap(index),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 1.h),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: EdgeInsets.all(1.5.w),
                decoration: BoxDecoration(
                  color: isSelected
                      ? color.withValues(alpha: 0.1)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: CustomIconWidget(
                  iconName: iconName,
                  color: color,
                  size: 24,
                ),
              ),
              SizedBox(height: 0.5.h),
              Text(
                label,
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: color,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

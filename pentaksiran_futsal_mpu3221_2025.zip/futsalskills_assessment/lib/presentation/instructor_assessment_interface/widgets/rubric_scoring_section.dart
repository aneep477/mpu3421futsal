import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class RubricScoringSection extends StatefulWidget {
  final String currentSkill;
  final int? selectedScore;
  final Function(int) onScoreSelected;

  const RubricScoringSection({
    super.key,
    required this.currentSkill,
    this.selectedScore,
    required this.onScoreSelected,
  });

  @override
  State<RubricScoringSection> createState() => _RubricScoringSectionState();
}

class _RubricScoringSectionState extends State<RubricScoringSection> {
  final Map<String, List<String>> skillCriteria = {
    "Sepakan Leret": [
      "Tidak dapat melakukan sepakan leret dengan betul",
      "Dapat melakukan sepakan leret tetapi dengan teknik yang lemah",
      "Dapat melakukan sepakan leret dengan teknik yang sederhana",
      "Dapat melakukan sepakan leret dengan teknik yang baik",
      "Dapat melakukan sepakan leret dengan teknik yang sangat baik dan konsisten"
    ],
    "Hantaran Pendek": [
      "Tidak dapat melakukan hantaran pendek dengan tepat",
      "Dapat melakukan hantaran pendek tetapi kurang tepat",
      "Dapat melakukan hantaran pendek dengan ketepatan sederhana",
      "Dapat melakukan hantaran pendek dengan ketepatan yang baik",
      "Dapat melakukan hantaran pendek dengan ketepatan yang sangat baik"
    ],
    "Menjaring": [
      "Tidak dapat menjaringkan bola ke dalam gol",
      "Dapat menjaringkan bola tetapi dengan ketepatan yang rendah",
      "Dapat menjaringkan bola dengan ketepatan sederhana",
      "Dapat menjaringkan bola dengan ketepatan yang baik",
      "Dapat menjaringkan bola dengan ketepatan yang sangat tinggi"
    ],
    "Menjaga Gol": [
      "Tidak dapat menjaga gol dengan berkesan",
      "Dapat menjaga gol tetapi dengan teknik yang lemah",
      "Dapat menjaga gol dengan teknik yang sederhana",
      "Dapat menjaga gol dengan teknik yang baik",
      "Dapat menjaga gol dengan teknik yang sangat baik dan refleks pantas"
    ],
    "Undang-Undang": [
      "Tidak memahami undang-undang futsal",
      "Memahami undang-undang futsal pada tahap asas",
      "Memahami undang-undang futsal pada tahap sederhana",
      "Memahami undang-undang futsal dengan baik",
      "Memahami undang-undang futsal dengan sangat baik dan boleh menjelaskan"
    ],
    "Teknik": [
      "Tidak menguasai teknik asas futsal",
      "Menguasai teknik asas futsal pada tahap permulaan",
      "Menguasai teknik asas futsal pada tahap sederhana",
      "Menguasai teknik asas futsal dengan baik",
      "Menguasai teknik asas futsal dengan sangat baik dan konsisten"
    ],
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(context),
          SizedBox(height: 2.h),
          _buildRubricScale(context),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        CustomIconWidget(
          iconName: 'checklist',
          color: colorScheme.primary,
          size: 6.w,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Rubrik Penilaian",
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
              Text(
                widget.currentSkill,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: colorScheme.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRubricScale(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final criteria = skillCriteria[widget.currentSkill] ?? [];

    return Column(
      children: List.generate(5, (index) {
        final score = index + 1;
        final isSelected = widget.selectedScore == score;
        final criterion = index < criteria.length
            ? criteria[index]
            : "Kriteria tidak tersedia";

        return Container(
          margin: EdgeInsets.only(bottom: 2.h),
          child: InkWell(
            onTap: () {
              HapticFeedback.selectionClick();
              widget.onScoreSelected(score);
            },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: isSelected
                    ? colorScheme.primary.withValues(alpha: 0.1)
                    : colorScheme.surfaceContainerHighest
                        .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected
                      ? colorScheme.primary
                      : colorScheme.outline.withValues(alpha: 0.2),
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8.w,
                    height: 8.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isSelected
                          ? colorScheme.primary
                          : colorScheme.outline.withValues(alpha: 0.3),
                      border: Border.all(
                        color: isSelected
                            ? colorScheme.primary
                            : colorScheme.outline,
                        width: 2,
                      ),
                    ),
                    child: isSelected
                        ? CustomIconWidget(
                            iconName: 'check',
                            color: colorScheme.onPrimary,
                            size: 4.w,
                          )
                        : null,
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              "Tahap $score",
                              style: theme.textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: isSelected
                                    ? colorScheme.primary
                                    : colorScheme.onSurface,
                              ),
                            ),
                            SizedBox(width: 2.w),
                            ...List.generate(score, (starIndex) {
                              return CustomIconWidget(
                                iconName: 'star',
                                color: Colors.amber,
                                size: 3.w,
                              );
                            }),
                          ],
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          criterion,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                            height: 1.4,
                          ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }),
    );
  }
}

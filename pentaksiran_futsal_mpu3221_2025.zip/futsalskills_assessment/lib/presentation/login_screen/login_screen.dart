import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/course_branding_widget.dart';
import './widgets/login_form_widget.dart';
import './widgets/register_link_widget.dart';
import 'widgets/course_branding_widget.dart';
import 'widgets/login_form_widget.dart';
import 'widgets/register_link_widget.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isLoading = false;
  final FocusNode _focusNode = FocusNode();

  // Mock credentials for testing
  final Map<String, Map<String, dynamic>> _mockCredentials = {
    'student': {
      'id': '123456',
      'password': 'student123',
      'name': 'Ahmad Faiz',
    },
    'instructor': {
      'id': '789012',
      'password': 'instructor123',
      'name': 'Dr. Sarah Abdullah',
    },
  };

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _handleLogin(
      String userId, String password, bool isStudent) async {
    setState(() => _isLoading = true);

    try {
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 2));

      final userType = isStudent ? 'student' : 'instructor';
      final mockUser = _mockCredentials[userType];

      if (mockUser != null &&
          mockUser['id'] == userId &&
          mockUser['password'] == password) {
        // Success haptic feedback
        HapticFeedback.lightImpact();

        // Navigate based on user role
        if (isStudent) {
          Navigator.pushReplacementNamed(context, '/student-dashboard');
        } else {
          Navigator.pushReplacementNamed(
              context, '/instructor-assessment-interface');
        }
      } else {
        // Show error message
        _showErrorMessage(
            'ID pengguna atau kata laluan tidak sah. Sila cuba lagi.');
      }
    } catch (e) {
      _showErrorMessage(
          'Ralat rangkaian. Sila periksa sambungan internet anda.');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showErrorMessage(String message) {
    HapticFeedback.heavyImpact();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              CustomIconWidget(
                iconName: 'error_outline',
                color: AppTheme.lightTheme.colorScheme.onError,
                size: 20,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Text(
                  message,
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onError,
                  ),
                ),
              ),
            ],
          ),
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
          duration: const Duration(seconds: 4),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom,
              ),
              child: IntrinsicHeight(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 6.w),
                  child: Column(
                    children: [
                      SizedBox(height: 8.h),
                      const CourseBrandingWidget(),
                      SizedBox(height: 6.h),
                      Expanded(
                        child: Column(
                          children: [
                            LoginFormWidget(
                              onLogin: _handleLogin,
                              isLoading: _isLoading,
                            ),
                            const Spacer(),
                            const RegisterLinkWidget(),
                            SizedBox(height: 2.h),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
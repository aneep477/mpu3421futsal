import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/assessment_criteria_section.dart';
import './widgets/assessment_overview_card.dart';
import './widgets/camera_capture_interface.dart';
import './widgets/comments_section.dart';
import './widgets/current_performance_highlight.dart';
import './widgets/photo_evidence_gallery.dart';
import './widgets/related_assessments_carousel.dart';

class SkillAssessmentDetail extends StatefulWidget {
  const SkillAssessmentDetail({super.key});

  @override
  State<SkillAssessmentDetail> createState() => _SkillAssessmentDetailState();
}

class _SkillAssessmentDetailState extends State<SkillAssessmentDetail> {
  late Map<String, dynamic> _assessmentData;
  late List<Map<String, dynamic>> _evidenceList;
  late List<Map<String, dynamic>> _comments;
  late List<Map<String, dynamic>> _relatedAssessments;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _initializeMockData();
  }

  void _initializeMockData() {
    _assessmentData = {
      'skillName': 'Sepakan Leret (Side Kick)',
      'category': 'Teknikal',
      'date': '11/08/2025',
      'instructor': 'Dr. Ahmad Razak',
      'currentLevel': 3,
      'status': 'completed', // 'pending', 'in_progress', 'completed'
    };

    _evidenceList = [
      {
        'id': 1,
        'url':
            'https://images.pexels.com/photos/274422/pexels-photo-274422.jpeg',
        'type': 'photo',
        'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
        'description': 'Posisi kaki semasa sepakan leret',
      },
      {
        'id': 2,
        'url':
            'https://images.pexels.com/photos/1171084/pexels-photo-1171084.jpeg',
        'type': 'video',
        'timestamp': DateTime.now().subtract(const Duration(hours: 1)),
        'description': 'Video demonstrasi sepakan leret',
      },
      {
        'id': 3,
        'url':
            'https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg',
        'type': 'photo',
        'timestamp': DateTime.now().subtract(const Duration(minutes: 30)),
        'description': 'Hasil sepakan ke arah sasaran',
      },
    ];

    _comments = [
      {
        'id': 1,
        'authorName': 'Dr. Ahmad Razak',
        'isInstructor': true,
        'content':
            'Prestasi yang baik! Posisi badan sudah betul, tetapi perlu fokus pada ketepatan sasaran. Cuba latih lagi dengan jarak yang berbeza.',
        'timestamp': DateTime.now().subtract(const Duration(hours: 3)),
      },
      {
        'id': 2,
        'authorName': 'Ahmad Faiz',
        'isInstructor': false,
        'content':
            'Terima kasih atas maklum balas, Dr. Ahmad. Saya akan cuba latihan tambahan untuk meningkatkan ketepatan.',
        'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
      },
      {
        'id': 3,
        'authorName': 'Dr. Ahmad Razak',
        'isInstructor': true,
        'content':
            'Bagus! Jangan lupa fokus pada follow-through selepas sepakan. Ini akan membantu meningkatkan kuasa dan ketepatan.',
        'timestamp': DateTime.now().subtract(const Duration(hours: 1)),
      },
    ];

    _relatedAssessments = [
      {
        'skillName': 'Hantaran Pendek',
        'category': 'Teknikal',
        'currentLevel': 4,
        'isCompleted': true,
        'progress': 0.8,
      },
      {
        'skillName': 'Menjaring',
        'category': 'Teknikal',
        'currentLevel': 2,
        'isCompleted': false,
        'progress': 0.4,
      },
      {
        'skillName': 'Menjaga Gol',
        'category': 'Teknikal',
        'currentLevel': 0,
        'isCompleted': false,
        'progress': 0.0,
      },
      {
        'skillName': 'Undang-Undang',
        'category': 'Mental',
        'currentLevel': 5,
        'isCompleted': true,
        'progress': 1.0,
      },
    ];
  }

  Map<String, dynamic> _getCriteriaData() {
    return {
      'description':
          'Penilaian sepakan leret berdasarkan teknik, ketepatan, kuasa, dan konsistensi. Setiap tahap mempunyai indikator prestasi yang jelas.',
      'currentLevel': _assessmentData['currentLevel'],
      'rubricLevels': [
        {
          'level': 1,
          'title': 'Tahap 1 - Pemula',
          'subtitle': 'Memerlukan bimbingan penuh',
          'indicators': [
            'Posisi badan tidak stabil semasa sepakan',
            'Kaki penyokong tidak berada pada kedudukan yang betul',
            'Sepakan tidak tepat dan kurang kuasa',
            'Memerlukan bantuan pensyarah untuk setiap percubaan',
          ],
        },
        {
          'level': 2,
          'title': 'Tahap 2 - Berkembang',
          'subtitle': 'Memerlukan sedikit bimbingan',
          'indicators': [
            'Posisi badan mula stabil tetapi masih perlu diperbaiki',
            'Kaki penyokong kadang-kadang pada kedudukan yang betul',
            'Sepakan mula menunjukkan arah tetapi kurang konsisten',
            'Boleh melakukan dengan bimbingan minimum',
          ],
        },
        {
          'level': 3,
          'title': 'Tahap 3 - Cekap',
          'subtitle': 'Boleh melakukan secara bebas',
          'indicators': [
            'Posisi badan stabil dan seimbang',
            'Kaki penyokong sentiasa pada kedudukan yang betul',
            'Sepakan tepat ke arah sasaran dengan kuasa sederhana',
            'Boleh melakukan tanpa bimbingan pensyarah',
          ],
        },
        {
          'level': 4,
          'title': 'Tahap 4 - Mahir',
          'subtitle': 'Prestasi yang konsisten',
          'indicators': [
            'Teknik sepakan yang sempurna dan konsisten',
            'Ketepatan tinggi dalam pelbagai jarak',
            'Kuasa sepakan yang bersesuaian dengan situasi',
            'Boleh menyesuaikan teknik mengikut keperluan permainan',
          ],
        },
        {
          'level': 5,
          'title': 'Tahap 5 - Pakar',
          'subtitle': 'Prestasi cemerlang dan boleh membimbing',
          'indicators': [
            'Menguasai semua aspek sepakan leret dengan sempurna',
            'Boleh melakukan sepakan dalam pelbagai situasi permainan',
            'Menunjukkan kreativiti dan inovasi dalam teknik',
            'Boleh membimbing dan mengajar rakan-rakan',
          ],
        },
      ],
    };
  }

  Map<String, dynamic> _getPerformanceData() {
    return {
      'currentLevel': _assessmentData['currentLevel'],
      'feedback':
          'Prestasi yang memberangsangkan! Anda telah menguasai teknik asas sepakan leret dengan baik. Posisi badan dan kaki penyokong sudah betul, dan ketepatan sepakan berada pada tahap yang memuaskan. Untuk meningkatkan ke tahap seterusnya, fokus pada konsistensi dan kuasa sepakan dalam pelbagai jarak.',
      'strengths': [
        'Posisi badan yang stabil dan seimbang',
        'Teknik kaki penyokong yang betul',
        'Ketepatan sepakan yang baik pada jarak pendek',
        'Menunjukkan pemahaman yang baik tentang teknik asas',
      ],
      'improvements': [
        'Tingkatkan kuasa sepakan untuk jarak yang lebih jauh',
        'Latih konsistensi dalam pelbagai kedudukan',
        'Perbaiki ketepatan pada sasaran yang lebih kecil',
        'Kembangkan variasi sepakan mengikut situasi permainan',
      ],
    };
  }

  void _showCameraInterface() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CameraCaptureInterface(
          onImageCaptured: _handleImageCaptured,
          onVideoCaptured: _handleVideoCaptured,
          onClose: () => Navigator.pop(context),
        ),
      ),
    );
  }

  void _handleImageCaptured(String imagePath) {
    setState(() {
      _evidenceList.add({
        'id': _evidenceList.length + 1,
        'url': imagePath,
        'type': 'photo',
        'timestamp': DateTime.now(),
        'description': 'Bukti foto baru',
      });
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Foto berjaya disimpan sebagai bukti penilaian'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _handleVideoCaptured(String videoPath) {
    setState(() {
      _evidenceList.add({
        'id': _evidenceList.length + 1,
        'url': videoPath,
        'type': 'video',
        'timestamp': DateTime.now(),
        'description': 'Bukti video baru',
      });
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Video berjaya disimpan sebagai bukti penilaian'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _handleAddComment(String comment) {
    setState(() {
      _comments.add({
        'id': _comments.length + 1,
        'authorName': 'Ahmad Faiz',
        'isInstructor': false,
        'content': comment,
        'timestamp': DateTime.now(),
      });
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Komen berjaya dihantar kepada pensyarah'),
      ),
    );
  }

  void _handleRelatedAssessmentTap(Map<String, dynamic> assessment) {
    HapticFeedback.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Membuka penilaian ${assessment['skillName']}...'),
      ),
    );

    // Navigate to the same screen with different data
    Navigator.pushNamed(context, '/skill-assessment-detail');
  }

  void _handleSubmitAssessment() {
    setState(() {
      _isLoading = true;
    });

    // Simulate submission process
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _assessmentData['status'] = 'submitted';
        });

        HapticFeedback.lightImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Penilaian berjaya dihantar untuk semakan'),
            backgroundColor: Colors.green,
          ),
        );
      }
    });
  }

  void _handleViewResults() {
    HapticFeedback.selectionClick();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Keputusan Penilaian'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Kemahiran: ${_assessmentData['skillName']}'),
            SizedBox(height: 1.h),
            Text('Tahap Dicapai: ${_assessmentData['currentLevel']}/5'),
            SizedBox(height: 1.h),
            Text('Status: Selesai'),
            SizedBox(height: 2.h),
            const Text(
                'Keputusan penuh boleh dilihat dalam laporan penilaian.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Laporan penilaian akan dimuat turun...'),
                ),
              );
            },
            child: const Text('Muat Turun Laporan'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final status = _assessmentData['status'] as String;

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: Text(
          _assessmentData['skillName'] as String,
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
            color: theme.colorScheme.onPrimary,
          ),
        ),
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: theme.colorScheme.onPrimary,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back_ios',
            color: theme.colorScheme.onPrimary,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: CustomIconWidget(
              iconName: 'share',
              color: theme.colorScheme.onPrimary,
              size: 20,
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content:
                      Text('Fungsi perkongsian akan tersedia tidak lama lagi'),
                ),
              );
            },
          ),
          IconButton(
            icon: CustomIconWidget(
              iconName: 'bookmark_border',
              color: theme.colorScheme.onPrimary,
              size: 20,
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Penilaian telah ditanda buku'),
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            AssessmentOverviewCard(assessmentData: _assessmentData),
            PhotoEvidenceGallery(
              evidenceList: _evidenceList,
              onAddEvidence: _showCameraInterface,
            ),
            AssessmentCriteriaSection(criteriaData: _getCriteriaData()),
            CurrentPerformanceHighlight(performanceData: _getPerformanceData()),
            CommentsSection(
              comments: _comments,
              onAddComment: _handleAddComment,
            ),
            RelatedAssessmentsCarousel(
              relatedAssessments: _relatedAssessments,
              onAssessmentTap: _handleRelatedAssessmentTap,
            ),
            SizedBox(height: 12.h), // Space for bottom actions
          ],
        ),
      ),
      bottomSheet: _buildBottomActions(theme, status),
    );
  }

  Widget _buildBottomActions(ThemeData theme, String status) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (status == 'pending' || status == 'in_progress') ...[
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _showCameraInterface,
                      icon: CustomIconWidget(
                        iconName: 'add_a_photo',
                        color: theme.colorScheme.primary,
                        size: 20,
                      ),
                      label: const Text('Ambil Foto/Video'),
                      style: OutlinedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 2.h),
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _isLoading ? null : _handleSubmitAssessment,
                      icon: _isLoading
                          ? SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: theme.colorScheme.onPrimary,
                              ),
                            )
                          : CustomIconWidget(
                              iconName: 'send',
                              color: theme.colorScheme.onPrimary,
                              size: 20,
                            ),
                      label: Text(
                          _isLoading ? 'Menghantar...' : 'Hantar Assessment'),
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 2.h),
                      ),
                    ),
                  ),
                ],
              ),
            ] else if (status == 'completed') ...[
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _showCameraInterface,
                      icon: CustomIconWidget(
                        iconName: 'add_a_photo',
                        color: theme.colorScheme.primary,
                        size: 20,
                      ),
                      label: const Text('Tambah Bukti'),
                      style: OutlinedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 2.h),
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _handleViewResults,
                      icon: CustomIconWidget(
                        iconName: 'visibility',
                        color: theme.colorScheme.onPrimary,
                        size: 20,
                      ),
                      label: const Text('Lihat Keputusan'),
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 2.h),
                      ),
                    ),
                  ),
                ],
              ),
            ] else ...[
              ElevatedButton.icon(
                onPressed: _handleViewResults,
                icon: CustomIconWidget(
                  iconName: 'visibility',
                  color: theme.colorScheme.onPrimary,
                  size: 20,
                ),
                label: const Text('Lihat Keputusan Penuh'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  minimumSize: Size(double.infinity, 6.h),
                ),
              ),
            ],
            SizedBox(height: 1.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: 'info_outline',
                  color: theme.colorScheme.onSurfaceVariant,
                  size: 16,
                ),
                SizedBox(width: 2.w),
                Text(
                  status == 'completed'
                      ? 'Penilaian selesai • Boleh menambah bukti tambahan'
                      : 'Pastikan semua bukti telah diambil sebelum menghantar',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

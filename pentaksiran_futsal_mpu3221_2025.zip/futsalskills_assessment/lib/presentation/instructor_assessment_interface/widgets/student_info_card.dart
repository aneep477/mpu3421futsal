import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class StudentInfoCard extends StatelessWidget {
  final Map<String, dynamic> studentData;

  const StudentInfoCard({
    super.key,
    required this.studentData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          _buildStudentPhoto(context),
          SizedBox(width: 4.w),
          Expanded(
            child: _buildStudentDetails(context),
          ),
        ],
      ),
    );
  }

  Widget _buildStudentPhoto(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      width: 20.w,
      height: 20.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.3),
          width: 2,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: studentData["photo"] != null
            ? CustomImageWidget(
                imageUrl: studentData["photo"] as String,
                width: 20.w,
                height: 20.w,
                fit: BoxFit.cover,
              )
            : Container(
                color: colorScheme.surfaceContainerHighest,
                child: CustomIconWidget(
                  iconName: 'person',
                  color: colorScheme.onSurfaceVariant,
                  size: 8.w,
                ),
              ),
      ),
    );
  }

  Widget _buildStudentDetails(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          studentData["name"] as String? ?? "Nama Pelajar",
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color: colorScheme.onSurface,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        SizedBox(height: 0.5.h),
        _buildInfoRow(
          context,
          "ID Pelajar",
          studentData["studentId"] as String? ?? "A12345678",
        ),
        SizedBox(height: 0.5.h),
        _buildInfoRow(
          context,
          "Kelas",
          studentData["class"] as String? ?? "MPU3421-01",
        ),
        SizedBox(height: 0.5.h),
        _buildInfoRow(
          context,
          "Kumpulan",
          studentData["group"] as String? ?? "Kumpulan A",
        ),
      ],
    );
  }

  Widget _buildInfoRow(BuildContext context, String label, String value) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        Text(
          "$label: ",
          style: theme.textTheme.bodySmall?.copyWith(
            color: colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.w500,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurface,
              fontWeight: FontWeight.w400,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PersonalInfoCardWidget extends StatefulWidget {
  final Map<String, dynamic> personalInfo;
  final Function(Map<String, dynamic>) onInfoUpdated;

  const PersonalInfoCardWidget({
    super.key,
    required this.personalInfo,
    required this.onInfoUpdated,
  });

  @override
  State<PersonalInfoCardWidget> createState() => _PersonalInfoCardWidgetState();
}

class _PersonalInfoCardWidgetState extends State<PersonalInfoCardWidget> {
  bool _isEditing = false;
  late Map<String, TextEditingController> _controllers;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _initializeControllers();
  }

  void _initializeControllers() {
    _controllers = {
      'phone': TextEditingController(
          text: widget.personalInfo["phone"] as String? ?? ""),
      'email': TextEditingController(
          text: widget.personalInfo["email"] as String? ?? ""),
      'address': TextEditingController(
          text: widget.personalInfo["address"] as String? ?? ""),
      'emergencyContact': TextEditingController(
          text: widget.personalInfo["emergencyContact"] as String? ?? ""),
      'emergencyPhone': TextEditingController(
          text: widget.personalInfo["emergencyPhone"] as String? ?? ""),
    };
  }

  @override
  void dispose() {
    _controllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  void _toggleEdit() {
    setState(() {
      _isEditing = !_isEditing;
      if (!_isEditing) {
        _saveChanges();
      }
    });
  }

  void _saveChanges() {
    if (_formKey.currentState?.validate() ?? false) {
      final updatedInfo = Map<String, dynamic>.from(widget.personalInfo);
      _controllers.forEach((key, controller) {
        updatedInfo[key] = controller.text;
      });
      widget.onInfoUpdated(updatedInfo);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Personal information updated successfully'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCardHeader(context),
            SizedBox(height: 2.h),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildInfoField(
                    context,
                    'Phone Number',
                    'phone',
                    Icons.phone_outlined,
                    validator: _validatePhone,
                  ),
                  SizedBox(height: 2.h),
                  _buildInfoField(
                    context,
                    'Email Address',
                    'email',
                    Icons.email_outlined,
                    validator: _validateEmail,
                  ),
                  SizedBox(height: 2.h),
                  _buildInfoField(
                    context,
                    'Home Address',
                    'address',
                    Icons.home_outlined,
                    maxLines: 2,
                  ),
                  SizedBox(height: 2.h),
                  _buildInfoField(
                    context,
                    'Emergency Contact',
                    'emergencyContact',
                    Icons.contact_emergency_outlined,
                  ),
                  SizedBox(height: 2.h),
                  _buildInfoField(
                    context,
                    'Emergency Phone',
                    'emergencyPhone',
                    Icons.phone_in_talk_outlined,
                    validator: _validatePhone,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCardHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        CustomIconWidget(
          iconName: 'person_outline',
          color: colorScheme.primary,
          size: 6.w,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Text(
            'Personal Information',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        IconButton(
          onPressed: _toggleEdit,
          icon: CustomIconWidget(
            iconName: _isEditing ? 'save' : 'edit',
            color: _isEditing ? AppTheme.successLight : colorScheme.primary,
            size: 5.w,
          ),
          tooltip: _isEditing ? 'Save Changes' : 'Edit Information',
        ),
      ],
    );
  }

  Widget _buildInfoField(
    BuildContext context,
    String label,
    String key,
    IconData icon, {
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: theme.textTheme.labelLarge?.copyWith(
            color: colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 0.5.h),
        TextFormField(
          controller: _controllers[key],
          enabled: _isEditing,
          maxLines: maxLines,
          validator: validator,
          decoration: InputDecoration(
            prefixIcon: CustomIconWidget(
              iconName: icon.codePoint.toString(),
              color: colorScheme.onSurfaceVariant,
              size: 5.w,
            ),
            filled: true,
            fillColor: _isEditing
                ? colorScheme.surface
                : colorScheme.surface.withValues(alpha: 0.5),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: colorScheme.outline.withValues(alpha: 0.5),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: colorScheme.outline.withValues(alpha: 0.5),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: colorScheme.primary,
                width: 2,
              ),
            ),
            disabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: colorScheme.outline.withValues(alpha: 0.3),
              ),
            ),
          ),
        ),
      ],
    );
  }

  String? _validatePhone(String? value) {
    if (value == null || value.isEmpty) {
      return 'Phone number is required';
    }
    if (!RegExp(r'^(\+?6?01)[0-46-9]-*[0-9]{7,8}$').hasMatch(value)) {
      return 'Please enter a valid Malaysian phone number';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email address is required';
    }
    if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  }
}

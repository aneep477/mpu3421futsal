import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Navigation item data structure for bottom navigation
class BottomNavItem {
  final IconData icon;
  final IconData? activeIcon;
  final String label;
  final String route;

  const BottomNavItem({
    required this.icon,
    this.activeIcon,
    required this.label,
    required this.route,
  });
}

/// Custom Bottom Navigation Bar implementing Contemporary Academic Minimalism
/// Provides consistent navigation with micro-feedback and smooth transitions
class CustomBottomBar extends StatefulWidget {
  final int currentIndex;
  final Function(int)? onTap;
  final List<BottomNavItem> items;
  final Color? backgroundColor;
  final Color? selectedItemColor;
  final Color? unselectedItemColor;
  final double elevation;

  const CustomBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
    required this.items,
    this.backgroundColor,
    this.selectedItemColor,
    this.unselectedItemColor,
    this.elevation = 2.0,
  });

  @override
  State<CustomBottomBar> createState() => _CustomBottomBarState();
}

class _CustomBottomBarState extends State<CustomBottomBar>
    with TickerProviderStateMixin {
  late List<AnimationController> _animationControllers;
  late List<Animation<double>> _scaleAnimations;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }

  void _initializeAnimations() {
    _animationControllers = List.generate(
      widget.items.length,
      (index) => AnimationController(
        duration: const Duration(milliseconds: 200),
        vsync: this,
      ),
    );

    _scaleAnimations = _animationControllers.map((controller) {
      return Tween<double>(begin: 1.0, end: 0.95).animate(
        CurvedAnimation(parent: controller, curve: Curves.easeInOut),
      );
    }).toList();

    // Animate the currently selected item
    if (widget.currentIndex < _animationControllers.length) {
      _animationControllers[widget.currentIndex].forward();
    }
  }

  @override
  void didUpdateWidget(CustomBottomBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.currentIndex != widget.currentIndex) {
      // Reset previous animation
      if (oldWidget.currentIndex < _animationControllers.length) {
        _animationControllers[oldWidget.currentIndex].reverse();
      }
      // Start new animation
      if (widget.currentIndex < _animationControllers.length) {
        _animationControllers[widget.currentIndex].forward();
      }
    }
  }

  @override
  void dispose() {
    for (final controller in _animationControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  void _handleTap(int index) {
    if (index == widget.currentIndex) return;

    // Haptic feedback for micro-feedback system
    HapticFeedback.lightImpact();

    // Navigate to the selected route
    Navigator.pushNamed(context, widget.items[index].route);

    // Call the onTap callback if provided
    widget.onTap?.call(index);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: widget.backgroundColor ?? colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Container(
          height: 72,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(widget.items.length, (index) {
              return _buildNavItem(context, index);
            }),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(BuildContext context, int index) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final item = widget.items[index];
    final isSelected = index == widget.currentIndex;

    return Expanded(
      child: AnimatedBuilder(
        animation: _scaleAnimations[index],
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimations[index].value,
            child: InkWell(
              onTap: () => _handleTap(index),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? (widget.selectedItemColor ?? colorScheme.primary)
                                .withValues(alpha: 0.1)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        isSelected ? (item.activeIcon ?? item.icon) : item.icon,
                        color: isSelected
                            ? (widget.selectedItemColor ?? colorScheme.primary)
                            : (widget.unselectedItemColor ??
                                colorScheme.onSurfaceVariant),
                        size: 24,
                      ),
                    ),
                    const SizedBox(height: 4),
                    AnimatedDefaultTextStyle(
                      duration: const Duration(milliseconds: 200),
                      style: theme.textTheme.labelSmall!.copyWith(
                        color: isSelected
                            ? (widget.selectedItemColor ?? colorScheme.primary)
                            : (widget.unselectedItemColor ??
                                colorScheme.onSurfaceVariant),
                        fontWeight:
                            isSelected ? FontWeight.w600 : FontWeight.w400,
                      ),
                      child: Text(
                        item.label,
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Student-focused bottom navigation bar
class CustomStudentBottomBar extends StatelessWidget {
  final int currentIndex;
  final Function(int)? onTap;

  const CustomStudentBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
  });

  static const List<BottomNavItem> _studentNavItems = [
    BottomNavItem(
      icon: Icons.dashboard_outlined,
      activeIcon: Icons.dashboard,
      label: 'Dashboard',
      route: '/student-dashboard',
    ),
    BottomNavItem(
      icon: Icons.assignment_outlined,
      activeIcon: Icons.assignment,
      label: 'Assessments',
      route: '/skill-assessment-detail',
    ),
    BottomNavItem(
      icon: Icons.person_outline,
      activeIcon: Icons.person,
      label: 'Profile',
      route: '/student-profile',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return CustomBottomBar(
      currentIndex: currentIndex,
      onTap: onTap,
      items: _studentNavItems,
    );
  }
}

/// Instructor-focused bottom navigation bar
class CustomInstructorBottomBar extends StatelessWidget {
  final int currentIndex;
  final Function(int)? onTap;

  const CustomInstructorBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
  });

  static const List<BottomNavItem> _instructorNavItems = [
    BottomNavItem(
      icon: Icons.dashboard_outlined,
      activeIcon: Icons.dashboard,
      label: 'Dashboard',
      route: '/student-dashboard',
    ),
    BottomNavItem(
      icon: Icons.rate_review_outlined,
      activeIcon: Icons.rate_review,
      label: 'Evaluate',
      route: '/instructor-assessment-interface',
    ),
    BottomNavItem(
      icon: Icons.analytics_outlined,
      activeIcon: Icons.analytics,
      label: 'Analytics',
      route: '/student-dashboard',
    ),
    BottomNavItem(
      icon: Icons.person_outline,
      activeIcon: Icons.person,
      label: 'Profile',
      route: '/student-profile',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return CustomBottomBar(
      currentIndex: currentIndex,
      onTap: onTap,
      items: _instructorNavItems,
    );
  }
}

/// Adaptive bottom navigation that switches based on user role
class CustomAdaptiveBottomBar extends StatelessWidget {
  final int currentIndex;
  final Function(int)? onTap;
  final UserRole userRole;

  const CustomAdaptiveBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
    required this.userRole,
  });

  @override
  Widget build(BuildContext context) {
    switch (userRole) {
      case UserRole.student:
        return CustomStudentBottomBar(
          currentIndex: currentIndex,
          onTap: onTap,
        );
      case UserRole.instructor:
        return CustomInstructorBottomBar(
          currentIndex: currentIndex,
          onTap: onTap,
        );
      case UserRole.admin:
        return CustomInstructorBottomBar(
          currentIndex: currentIndex,
          onTap: onTap,
        );
    }
  }
}

/// User role enumeration for adaptive navigation
enum UserRole {
  student,
  instructor,
  admin,
}

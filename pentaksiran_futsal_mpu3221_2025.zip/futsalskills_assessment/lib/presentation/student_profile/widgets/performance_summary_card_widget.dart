import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PerformanceSummaryCardWidget extends StatelessWidget {
  final Map<String, dynamic> performanceData;

  const PerformanceSummaryCardWidget({
    super.key,
    required this.performanceData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCardHeader(context),
            SizedBox(height: 3.h),
            _buildOverallProgress(context),
            SizedBox(height: 3.h),
            _buildSkillsChart(context),
            SizedBox(height: 3.h),
            _buildSkillsList(context),
          ],
        ),
      ),
    );
  }

  Widget _buildCardHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        CustomIconWidget(
          iconName: 'analytics',
          color: colorScheme.primary,
          size: 6.w,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Text(
            'Performance Summary',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
          decoration: BoxDecoration(
            color: AppTheme.successLight.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
            '${performanceData["overallScore"] as int? ?? 85}%',
            style: theme.textTheme.labelLarge?.copyWith(
              color: AppTheme.successLight,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildOverallProgress(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final overallScore =
        (performanceData["overallScore"] as int? ?? 85) / 100.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Overall Progress',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        LinearProgressIndicator(
          value: overallScore,
          backgroundColor: colorScheme.outline.withValues(alpha: 0.2),
          valueColor: AlwaysStoppedAnimation<Color>(
            _getProgressColor(overallScore),
          ),
          minHeight: 8,
        ),
        SizedBox(height: 1.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Current Performance',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
            Text(
              '${(overallScore * 100).toInt()}% Complete',
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSkillsChart(BuildContext context) {
    final theme = Theme.of(context);
    final skills = performanceData["skills"] as List<Map<String, dynamic>>? ??
        _getDefaultSkills();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Skills Breakdown',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),
        Container(
          height: 30.h,
          child: BarChart(
            BarChartData(
              alignment: BarChartAlignment.spaceAround,
              maxY: 100,
              barTouchData: BarTouchData(enabled: false),
              titlesData: FlTitlesData(
                show: true,
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final index = value.toInt();
                      if (index >= 0 && index < skills.length) {
                        return Padding(
                          padding: EdgeInsets.only(top: 1.h),
                          child: Text(
                            _getShortSkillName(skills[index]["name"] as String),
                            style: theme.textTheme.bodySmall,
                            textAlign: TextAlign.center,
                          ),
                        );
                      }
                      return const SizedBox.shrink();
                    },
                  ),
                ),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 8.w,
                    getTitlesWidget: (value, meta) {
                      return Text(
                        '${value.toInt()}',
                        style: theme.textTheme.bodySmall,
                      );
                    },
                  ),
                ),
                topTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              gridData: FlGridData(
                show: true,
                horizontalInterval: 20,
                getDrawingHorizontalLine: (value) {
                  return FlLine(
                    color: theme.colorScheme.outline.withValues(alpha: 0.2),
                    strokeWidth: 1,
                  );
                },
              ),
              borderData: FlBorderData(show: false),
              barGroups: skills.asMap().entries.map((entry) {
                final index = entry.key;
                final skill = entry.value;
                final score = skill["score"] as int? ?? 0;

                return BarChartGroupData(
                  x: index,
                  barRods: [
                    BarChartRodData(
                      toY: score.toDouble(),
                      color: _getSkillColor(score),
                      width: 6.w,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSkillsList(BuildContext context) {
    final theme = Theme.of(context);
    final skills = performanceData["skills"] as List<Map<String, dynamic>>? ??
        _getDefaultSkills();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Detailed Scores',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        ...skills.map((skill) => _buildSkillItem(context, skill)),
      ],
    );
  }

  Widget _buildSkillItem(BuildContext context, Map<String, dynamic> skill) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final name = skill["name"] as String? ?? "";
    final score = skill["score"] as int? ?? 0;
    final trend = skill["trend"] as String? ?? "stable";

    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  _getPerformanceLevel(score),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: _getSkillColor(score),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              CustomIconWidget(
                iconName: _getTrendIcon(trend),
                color: _getTrendColor(trend),
                size: 4.w,
              ),
              SizedBox(width: 2.w),
              Text(
                '$score%',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: _getSkillColor(score),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _getDefaultSkills() {
    return [
      {"name": "Sepakan Leret", "score": 88, "trend": "up"},
      {"name": "Hantaran Pendek", "score": 92, "trend": "up"},
      {"name": "Menjaring", "score": 85, "trend": "stable"},
      {"name": "Menjaga Gol", "score": 78, "trend": "down"},
      {"name": "Undang-Undang", "score": 95, "trend": "up"},
      {"name": "Teknik", "score": 82, "trend": "stable"},
    ];
  }

  String _getShortSkillName(String fullName) {
    switch (fullName) {
      case "Sepakan Leret":
        return "Sepakan";
      case "Hantaran Pendek":
        return "Hantaran";
      case "Menjaring":
        return "Menjaring";
      case "Menjaga Gol":
        return "Gol";
      case "Undang-Undang":
        return "Undang";
      case "Teknik":
        return "Teknik";
      default:
        return fullName.length > 8 ? fullName.substring(0, 8) : fullName;
    }
  }

  Color _getProgressColor(double progress) {
    if (progress >= 0.8) return AppTheme.successLight;
    if (progress >= 0.6) return AppTheme.warningLight;
    return AppTheme.errorLight;
  }

  Color _getSkillColor(int score) {
    if (score >= 80) return AppTheme.successLight;
    if (score >= 60) return AppTheme.warningLight;
    return AppTheme.errorLight;
  }

  String _getPerformanceLevel(int score) {
    if (score >= 90) return "Excellent";
    if (score >= 80) return "Good";
    if (score >= 70) return "Satisfactory";
    if (score >= 60) return "Needs Improvement";
    return "Poor";
  }

  String _getTrendIcon(String trend) {
    switch (trend) {
      case "up":
        return "trending_up";
      case "down":
        return "trending_down";
      default:
        return "trending_flat";
    }
  }

  Color _getTrendColor(String trend) {
    switch (trend) {
      case "up":
        return AppTheme.successLight;
      case "down":
        return AppTheme.errorLight;
      default:
        return AppTheme.warningLight;
    }
  }
}

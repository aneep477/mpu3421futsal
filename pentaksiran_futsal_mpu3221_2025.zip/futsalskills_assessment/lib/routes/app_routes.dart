import 'package:flutter/material.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/student_profile/student_profile.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/student_dashboard/student_dashboard.dart';
import '../presentation/skill_assessment_detail/skill_assessment_detail.dart';
import '../presentation/instructor_assessment_interface/instructor_assessment_interface.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String splash = '/splash-screen';
  static const String studentProfile = '/student-profile';
  static const String login = '/login-screen';
  static const String studentDashboard = '/student-dashboard';
  static const String skillAssessmentDetail = '/skill-assessment-detail';
  static const String instructorAssessmentInterface =
      '/instructor-assessment-interface';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    splash: (context) => const SplashScreen(),
    studentProfile: (context) => const StudentProfile(),
    login: (context) => const LoginScreen(),
    studentDashboard: (context) => const StudentDashboard(),
    skillAssessmentDetail: (context) => const SkillAssessmentDetail(),
    instructorAssessmentInterface: (context) =>
        const InstructorAssessmentInterface(),
    // TODO: Add your other routes here
  };
}

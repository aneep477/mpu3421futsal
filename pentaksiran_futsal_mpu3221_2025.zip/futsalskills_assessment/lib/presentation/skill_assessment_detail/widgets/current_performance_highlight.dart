import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class CurrentPerformanceHighlight extends StatelessWidget {
  final Map<String, dynamic> performanceData;

  const CurrentPerformanceHighlight({
    super.key,
    required this.performanceData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final currentLevel = performanceData['currentLevel'] as int? ?? 0;
    final feedback = performanceData['feedback'] as String? ?? '';
    final strengths =
        (performanceData['strengths'] as List?)?.cast<String>() ?? [];
    final improvements =
        (performanceData['improvements'] as List?)?.cast<String>() ?? [];

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(theme),
          SizedBox(height: 2.h),
          if (currentLevel > 0) ...[
            _buildCurrentLevelCard(theme),
            SizedBox(height: 3.h),
            if (feedback.isNotEmpty) _buildFeedbackSection(theme),
            if (strengths.isNotEmpty) ...[
              SizedBox(height: 2.h),
              _buildStrengthsSection(theme),
            ],
            if (improvements.isNotEmpty) ...[
              SizedBox(height: 2.h),
              _buildImprovementsSection(theme),
            ],
          ] else
            _buildPendingAssessment(theme),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(ThemeData theme) {
    return Row(
      children: [
        CustomIconWidget(
          iconName: 'trending_up',
          color: theme.colorScheme.primary,
          size: 20,
        ),
        SizedBox(width: 2.w),
        Text(
          'Prestasi Semasa',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color: theme.colorScheme.onSurface,
          ),
        ),
      ],
    );
  }

  Widget _buildCurrentLevelCard(ThemeData theme) {
    final currentLevel = performanceData['currentLevel'] as int? ?? 0;
    final levelColor = _getLevelColor(currentLevel);
    final levelTitle = _getLevelTitle(currentLevel);
    final levelDescription = _getLevelDescription(currentLevel);

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            levelColor.withValues(alpha: 0.1),
            levelColor.withValues(alpha: 0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: levelColor.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 16.w,
                height: 16.w,
                decoration: BoxDecoration(
                  color: levelColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: levelColor.withValues(alpha: 0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    '$currentLevel',
                    style: theme.textTheme.headlineSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      levelTitle,
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      levelDescription,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildProgressIndicator(theme),
        ],
      ),
    );
  }

  Widget _buildProgressIndicator(ThemeData theme) {
    final currentLevel = performanceData['currentLevel'] as int? ?? 0;
    final maxLevel = 5;
    final progress = currentLevel / maxLevel;

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Kemajuan Keseluruhan',
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
                color: theme.colorScheme.onSurface,
              ),
            ),
            Text(
              '${(progress * 100).toInt()}%',
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: _getLevelColor(currentLevel),
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        LinearProgressIndicator(
          value: progress,
          backgroundColor: theme.colorScheme.outline.withValues(alpha: 0.2),
          valueColor:
              AlwaysStoppedAnimation<Color>(_getLevelColor(currentLevel)),
          minHeight: 8,
        ),
      ],
    );
  }

  Widget _buildFeedbackSection(ThemeData theme) {
    final feedback = performanceData['feedback'] as String? ?? '';

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'feedback',
                color: theme.colorScheme.primary,
                size: 18,
              ),
              SizedBox(width: 2.w),
              Text(
                'Maklum Balas Pensyarah',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Text(
            feedback,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStrengthsSection(ThemeData theme) {
    final strengths =
        (performanceData['strengths'] as List?)?.cast<String>() ?? [];

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.green.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.green.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'thumb_up',
                color: Colors.green,
                size: 18,
              ),
              SizedBox(width: 2.w),
              Text(
                'Kekuatan',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          ...strengths.map((strength) => Padding(
                padding: EdgeInsets.only(bottom: 1.h),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomIconWidget(
                      iconName: 'check_circle',
                      color: Colors.green,
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        strength,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurface,
                          height: 1.3,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildImprovementsSection(ThemeData theme) {
    final improvements =
        (performanceData['improvements'] as List?)?.cast<String>() ?? [];

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.orange.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.orange.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'lightbulb',
                color: Colors.orange,
                size: 18,
              ),
              SizedBox(width: 2.w),
              Text(
                'Cadangan Penambahbaikan',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Colors.orange,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          ...improvements.map((improvement) => Padding(
                padding: EdgeInsets.only(bottom: 1.h),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomIconWidget(
                      iconName: 'arrow_forward',
                      color: Colors.orange,
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        improvement,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurface,
                          height: 1.3,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildPendingAssessment(ThemeData theme) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
          style: BorderStyle.solid,
        ),
      ),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: 'schedule',
            color: theme.colorScheme.onSurfaceVariant,
            size: 48,
          ),
          SizedBox(height: 2.h),
          Text(
            'Penilaian Belum Selesai',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Kemahiran ini masih dalam proses penilaian. Sila tunggu keputusan daripada pensyarah.',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Color _getLevelColor(int level) {
    switch (level) {
      case 1:
        return Colors.red;
      case 2:
        return Colors.orange;
      case 3:
        return Colors.amber;
      case 4:
        return Colors.lightGreen;
      case 5:
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getLevelTitle(int level) {
    switch (level) {
      case 1:
        return 'Tahap 1 - Pemula';
      case 2:
        return 'Tahap 2 - Berkembang';
      case 3:
        return 'Tahap 3 - Cekap';
      case 4:
        return 'Tahap 4 - Mahir';
      case 5:
        return 'Tahap 5 - Pakar';
      default:
        return 'Belum Dinilai';
    }
  }

  String _getLevelDescription(int level) {
    switch (level) {
      case 1:
        return 'Anda memerlukan bimbingan penuh untuk melaksanakan kemahiran ini dengan betul.';
      case 2:
        return 'Anda boleh melaksanakan kemahiran ini dengan sedikit bimbingan dan sokongan.';
      case 3:
        return 'Anda boleh melaksanakan kemahiran ini secara bebas dengan prestasi yang memuaskan.';
      case 4:
        return 'Anda menunjukkan prestasi yang konsisten dan boleh dipercayai dalam kemahiran ini.';
      case 5:
        return 'Anda mencapai tahap pakar dan boleh membimbing orang lain dalam kemahiran ini.';
      default:
        return 'Kemahiran ini belum dinilai lagi.';
    }
  }
}

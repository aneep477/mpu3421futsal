import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class AssessmentOverviewCard extends StatelessWidget {
  final Map<String, dynamic> assessmentData;

  const AssessmentOverviewCard({
    super.key,
    required this.assessmentData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(theme),
          SizedBox(height: 3.h),
          _buildAssessmentInfo(theme),
          SizedBox(height: 3.h),
          _buildPerformanceLevel(theme),
        ],
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color: theme.colorScheme.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: CustomIconWidget(
            iconName: 'sports_soccer',
            color: theme.colorScheme.primary,
            size: 24,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                assessmentData['skillName'] as String? ?? 'Kemahiran Futsal',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 0.5.h),
              Text(
                'Kategori: ${assessmentData['category'] as String? ?? 'Teknikal'}',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAssessmentInfo(ThemeData theme) {
    return Row(
      children: [
        Expanded(
          child: _buildInfoItem(
            theme,
            'calendar_today',
            'Tarikh',
            assessmentData['date'] as String? ?? '11/08/2025',
          ),
        ),
        SizedBox(width: 4.w),
        Expanded(
          child: _buildInfoItem(
            theme,
            'person',
            'Pensyarah',
            assessmentData['instructor'] as String? ?? 'Dr. Ahmad',
          ),
        ),
      ],
    );
  }

  Widget _buildInfoItem(
      ThemeData theme, String iconName, String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: theme.colorScheme.onSurfaceVariant,
              size: 16,
            ),
            SizedBox(width: 2.w),
            Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        Text(
          value,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurface,
            fontWeight: FontWeight.w500,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  Widget _buildPerformanceLevel(ThemeData theme) {
    final currentLevel = assessmentData['currentLevel'] as int? ?? 0;
    final maxLevel = 5;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Tahap Prestasi Semasa',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.onSurface,
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color:
                    _getLevelColor(currentLevel, theme).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                currentLevel > 0 ? 'Tahap $currentLevel' : 'Belum Dinilai',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: _getLevelColor(currentLevel, theme),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        Row(
          children: List.generate(maxLevel, (index) {
            final level = index + 1;
            final isActive = level <= currentLevel;
            final isNext = level == currentLevel + 1;

            return Expanded(
              child: Container(
                height: 8,
                margin: EdgeInsets.only(right: index < maxLevel - 1 ? 1.w : 0),
                decoration: BoxDecoration(
                  color: isActive
                      ? _getLevelColor(currentLevel, theme)
                      : isNext
                          ? _getLevelColor(currentLevel, theme)
                              .withValues(alpha: 0.3)
                          : theme.colorScheme.outline.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            );
          }),
        ),
        SizedBox(height: 1.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Pemula',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            Text(
              'Pakar',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Color _getLevelColor(int level, ThemeData theme) {
    switch (level) {
      case 1:
        return Colors.red;
      case 2:
        return Colors.orange;
      case 3:
        return Colors.amber;
      case 4:
        return Colors.lightGreen;
      case 5:
        return Colors.green;
      default:
        return theme.colorScheme.onSurfaceVariant;
    }
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class QuickScoringButtons extends StatelessWidget {
  final int? selectedScore;
  final Function(int) onScoreSelected;

  const QuickScoringButtons({
    super.key,
    this.selectedScore,
    required this.onScoreSelected,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(context),
          SizedBox(height: 2.h),
          _buildQuickButtons(context),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        CustomIconWidget(
          iconName: 'speed',
          color: colorScheme.primary,
          size: 6.w,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Penilaian Pantas",
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
              Text(
                "Pilih skor dengan cepat semasa demonstrasi",
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildQuickButtons(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> scoreData = [
      {
        "score": 1,
        "label": "Lemah",
        "color": Colors.red,
        "icon": "sentiment_very_dissatisfied",
      },
      {
        "score": 2,
        "label": "Kurang",
        "color": Colors.orange,
        "icon": "sentiment_dissatisfied",
      },
      {
        "score": 3,
        "label": "Sederhana",
        "color": Colors.amber,
        "icon": "sentiment_neutral",
      },
      {
        "score": 4,
        "label": "Baik",
        "color": Colors.lightGreen,
        "icon": "sentiment_satisfied",
      },
      {
        "score": 5,
        "label": "Cemerlang",
        "color": Colors.green,
        "icon": "sentiment_very_satisfied",
      },
    ];

    return Row(
      children: scoreData.map((data) {
        final score = data["score"] as int;
        final label = data["label"] as String;
        final color = data["color"] as Color;
        final icon = data["icon"] as String;
        final isSelected = selectedScore == score;

        return Expanded(
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 1.w),
            child: GestureDetector(
              onTap: () {
                HapticFeedback.mediumImpact();
                onScoreSelected(score);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeInOut,
                padding: EdgeInsets.symmetric(vertical: 2.h),
                decoration: BoxDecoration(
                  color: isSelected
                      ? color.withValues(alpha: 0.2)
                      : colorScheme.surfaceContainerHighest
                          .withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected
                        ? color
                        : colorScheme.outline.withValues(alpha: 0.3),
                    width: isSelected ? 2 : 1,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: color.withValues(alpha: 0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedScale(
                      scale: isSelected ? 1.2 : 1.0,
                      duration: const Duration(milliseconds: 200),
                      child: CustomIconWidget(
                        iconName: icon,
                        color:
                            isSelected ? color : colorScheme.onSurfaceVariant,
                        size: 6.w,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      score.toString(),
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: isSelected ? color : colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      label,
                      style: theme.textTheme.labelSmall?.copyWith(
                        fontWeight: FontWeight.w500,
                        color:
                            isSelected ? color : colorScheme.onSurfaceVariant,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Custom Tab Bar implementing Contemporary Academic Minimalism
/// Provides smooth gesture-driven navigation with contextual indicators
class CustomTabBar extends StatefulWidget implements PreferredSizeWidget {
  final List<CustomTab> tabs;
  final TabController? controller;
  final Function(int)? onTap;
  final bool isScrollable;
  final Color? indicatorColor;
  final Color? labelColor;
  final Color? unselectedLabelColor;
  final EdgeInsetsGeometry? labelPadding;
  final EdgeInsetsGeometry? indicatorPadding;
  final double indicatorWeight;
  final TabBarIndicatorSize indicatorSize;
  final BorderRadius? indicatorBorderRadius;

  const CustomTabBar({
    super.key,
    required this.tabs,
    this.controller,
    this.onTap,
    this.isScrollable = false,
    this.indicatorColor,
    this.labelColor,
    this.unselectedLabelColor,
    this.labelPadding,
    this.indicatorPadding,
    this.indicatorWeight = 3.0,
    this.indicatorSize = TabBarIndicatorSize.label,
    this.indicatorBorderRadius,
  });

  @override
  State<CustomTabBar> createState() => _CustomTabBarState();

  @override
  Size get preferredSize => const Size.fromHeight(48.0);
}

class _CustomTabBarState extends State<CustomTabBar>
    with TickerProviderStateMixin {
  late TabController _controller;
  bool _controllerCreated = false;

  @override
  void initState() {
    super.initState();
    _initializeController();
  }

  void _initializeController() {
    if (widget.controller != null) {
      _controller = widget.controller!;
    } else {
      _controller = TabController(
        length: widget.tabs.length,
        vsync: this,
      );
      _controllerCreated = true;
    }
  }

  @override
  void didUpdateWidget(CustomTabBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.controller != oldWidget.controller) {
      if (_controllerCreated) {
        _controller.dispose();
      }
      _initializeController();
    }
  }

  @override
  void dispose() {
    if (_controllerCreated) {
      _controller.dispose();
    }
    super.dispose();
  }

  void _handleTap(int index) {
    // Haptic feedback for micro-feedback system
    HapticFeedback.selectionClick();
    widget.onTap?.call(index);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: colorScheme.outline.withValues(alpha: 0.2),
            width: 1.0,
          ),
        ),
      ),
      child: TabBar(
        controller: _controller,
        tabs: widget.tabs.map((tab) => _buildTab(context, tab)).toList(),
        onTap: _handleTap,
        isScrollable: widget.isScrollable,
        indicatorColor: widget.indicatorColor ?? colorScheme.primary,
        labelColor: widget.labelColor ?? colorScheme.primary,
        unselectedLabelColor:
            widget.unselectedLabelColor ?? colorScheme.onSurfaceVariant,
        labelPadding:
            widget.labelPadding ?? const EdgeInsets.symmetric(horizontal: 16),
        indicatorPadding: widget.indicatorPadding ?? EdgeInsets.zero,
        indicatorWeight: widget.indicatorWeight,
        indicatorSize: widget.indicatorSize,
        indicator: _buildIndicator(context),
        labelStyle: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w600,
          letterSpacing: 0.1,
        ),
        unselectedLabelStyle: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w400,
          letterSpacing: 0.1,
        ),
        splashFactory: NoSplash.splashFactory,
        overlayColor: WidgetStateProperty.all(Colors.transparent),
      ),
    );
  }

  Widget _buildTab(BuildContext context, CustomTab tab) {
    return Tab(
      icon: tab.icon != null ? Icon(tab.icon, size: 20) : null,
      text: tab.text,
      child: tab.child,
    );
  }

  Decoration _buildIndicator(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return BoxDecoration(
      color: widget.indicatorColor ?? colorScheme.primary,
      borderRadius: widget.indicatorBorderRadius ??
          const BorderRadius.vertical(top: Radius.circular(3)),
    );
  }
}

/// Custom tab data structure
class CustomTab {
  final String? text;
  final IconData? icon;
  final Widget? child;

  const CustomTab({
    this.text,
    this.icon,
    this.child,
  }) : assert(text != null || icon != null || child != null,
            'At least one of text, icon, or child must be provided');
}

/// Assessment categories tab bar for skill evaluation
class CustomAssessmentTabBar extends StatelessWidget
    implements PreferredSizeWidget {
  final TabController? controller;
  final Function(int)? onTap;

  const CustomAssessmentTabBar({
    super.key,
    this.controller,
    this.onTap,
  });

  static const List<CustomTab> _assessmentTabs = [
    CustomTab(
      text: 'Technical',
      icon: Icons.code_outlined,
    ),
    CustomTab(
      text: 'Communication',
      icon: Icons.chat_bubble_outline,
    ),
    CustomTab(
      text: 'Leadership',
      icon: Icons.groups_outlined,
    ),
    CustomTab(
      text: 'Problem Solving',
      icon: Icons.psychology_outlined,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return CustomTabBar(
      tabs: _assessmentTabs,
      controller: controller,
      onTap: onTap,
      isScrollable: true,
      indicatorBorderRadius: BorderRadius.circular(3),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(48.0);
}

/// Student progress tab bar for dashboard navigation
class CustomProgressTabBar extends StatelessWidget
    implements PreferredSizeWidget {
  final TabController? controller;
  final Function(int)? onTap;

  const CustomProgressTabBar({
    super.key,
    this.controller,
    this.onTap,
  });

  static const List<CustomTab> _progressTabs = [
    CustomTab(
      text: 'Overview',
      icon: Icons.dashboard_outlined,
    ),
    CustomTab(
      text: 'Completed',
      icon: Icons.check_circle_outline,
    ),
    CustomTab(
      text: 'In Progress',
      icon: Icons.schedule_outlined,
    ),
    CustomTab(
      text: 'Upcoming',
      icon: Icons.upcoming_outlined,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return CustomTabBar(
      tabs: _progressTabs,
      controller: controller,
      onTap: onTap,
      isScrollable: false,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(48.0);
}

/// Instructor evaluation tab bar for assessment interface
class CustomEvaluationTabBar extends StatelessWidget
    implements PreferredSizeWidget {
  final TabController? controller;
  final Function(int)? onTap;

  const CustomEvaluationTabBar({
    super.key,
    this.controller,
    this.onTap,
  });

  static const List<CustomTab> _evaluationTabs = [
    CustomTab(
      text: 'Rubric',
      icon: Icons.checklist_outlined,
    ),
    CustomTab(
      text: 'Notes',
      icon: Icons.note_outlined,
    ),
    CustomTab(
      text: 'Media',
      icon: Icons.photo_camera_outlined,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return CustomTabBar(
      tabs: _evaluationTabs,
      controller: controller,
      onTap: onTap,
      isScrollable: false,
      indicatorWeight: 4.0,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(48.0);
}

/// Adaptive tab bar that switches based on context
class CustomAdaptiveTabBar extends StatelessWidget
    implements PreferredSizeWidget {
  final TabBarType type;
  final TabController? controller;
  final Function(int)? onTap;

  const CustomAdaptiveTabBar({
    super.key,
    required this.type,
    this.controller,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    switch (type) {
      case TabBarType.assessment:
        return CustomAssessmentTabBar(
          controller: controller,
          onTap: onTap,
        );
      case TabBarType.progress:
        return CustomProgressTabBar(
          controller: controller,
          onTap: onTap,
        );
      case TabBarType.evaluation:
        return CustomEvaluationTabBar(
          controller: controller,
          onTap: onTap,
        );
    }
  }

  @override
  Size get preferredSize => const Size.fromHeight(48.0);
}

/// Tab bar type enumeration for adaptive behavior
enum TabBarType {
  assessment,
  progress,
  evaluation,
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Custom AppBar widget implementing Contemporary Academic Minimalism design
/// Provides consistent navigation header with subtle gradient and professional styling
class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final Widget? leading;
  final bool automaticallyImplyLeading;
  final bool centerTitle;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double elevation;
  final bool showBackButton;
  final VoidCallback? onBackPressed;
  final PreferredSizeWidget? bottom;

  const CustomAppBar({
    super.key,
    required this.title,
    this.actions,
    this.leading,
    this.automaticallyImplyLeading = true,
    this.centerTitle = true,
    this.backgroundColor,
    this.foregroundColor,
    this.elevation = 1.0,
    this.showBackButton = false,
    this.onBackPressed,
    this.bottom,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        // Subtle gradient implementation for visual hierarchy
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            backgroundColor ?? colorScheme.primary,
            (backgroundColor ?? colorScheme.primary).withValues(alpha: 0.95),
          ],
        ),
      ),
      child: AppBar(
        title: Text(
          title,
          style: theme.textTheme.titleLarge?.copyWith(
            color: foregroundColor ?? colorScheme.onPrimary,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.15,
          ),
        ),
        centerTitle: centerTitle,
        backgroundColor: Colors.transparent,
        foregroundColor: foregroundColor ?? colorScheme.onPrimary,
        elevation: elevation,
        shadowColor: colorScheme.shadow,
        automaticallyImplyLeading: automaticallyImplyLeading && !showBackButton,
        leading: _buildLeading(context),
        actions: _buildActions(context),
        bottom: bottom,
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: theme.brightness == Brightness.light
              ? Brightness.light
              : Brightness.dark,
          statusBarBrightness: theme.brightness,
        ),
      ),
    );
  }

  Widget? _buildLeading(BuildContext context) {
    if (leading != null) return leading;

    if (showBackButton) {
      return IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded),
        onPressed: onBackPressed ?? () => Navigator.of(context).pop(),
        tooltip: 'Back',
      );
    }

    return null;
  }

  List<Widget>? _buildActions(BuildContext context) {
    if (actions == null) return null;

    return actions!.map((action) {
      if (action is IconButton) {
        return Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: action,
        );
      }
      return action;
    }).toList();
  }

  @override
  Size get preferredSize => Size.fromHeight(
        kToolbarHeight + (bottom?.preferredSize.height ?? 0.0),
      );
}

/// Specialized AppBar for student dashboard with quick access actions
class CustomStudentAppBar extends CustomAppBar {
  const CustomStudentAppBar({
    super.key,
    required super.title,
  }) : super(
          actions: const [
            _NotificationButton(),
            _ProfileButton(),
          ],
        );
}

/// Specialized AppBar for instructor interface with assessment tools
class CustomInstructorAppBar extends CustomAppBar {
  const CustomInstructorAppBar({
    super.key,
    required super.title,
  }) : super(
          actions: const [
            _SaveButton(),
            _MoreOptionsButton(),
          ],
        );
}

/// Specialized AppBar for assessment detail with contextual actions
class CustomAssessmentAppBar extends CustomAppBar {
  const CustomAssessmentAppBar({
    super.key,
    required super.title,
  }) : super(
          showBackButton: true,
          actions: const [
            _ShareButton(),
            _BookmarkButton(),
          ],
        );
}

class _NotificationButton extends StatelessWidget {
  const _NotificationButton();

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.notifications_outlined),
      onPressed: () {
        // Navigate to notifications or show notification panel
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Notifications feature coming soon')),
        );
      },
      tooltip: 'Notifications',
    );
  }
}

class _ProfileButton extends StatelessWidget {
  const _ProfileButton();

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.account_circle_outlined),
      onPressed: () {
        Navigator.pushNamed(context, '/student-profile');
      },
      tooltip: 'Profile',
    );
  }
}

class _SaveButton extends StatelessWidget {
  const _SaveButton();

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.save_outlined),
      onPressed: () {
        // Implement save functionality with haptic feedback
        HapticFeedback.lightImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Assessment saved successfully')),
        );
      },
      tooltip: 'Save',
    );
  }
}

class _MoreOptionsButton extends StatelessWidget {
  const _MoreOptionsButton();

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.more_vert),
      onSelected: (value) {
        switch (value) {
          case 'export':
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Export feature coming soon')),
            );
            break;
          case 'settings':
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Settings feature coming soon')),
            );
            break;
        }
      },
      itemBuilder: (context) => [
        const PopupMenuItem(
          value: 'export',
          child: Row(
            children: [
              Icon(Icons.download_outlined),
              SizedBox(width: 12),
              Text('Export Data'),
            ],
          ),
        ),
        const PopupMenuItem(
          value: 'settings',
          child: Row(
            children: [
              Icon(Icons.settings_outlined),
              SizedBox(width: 12),
              Text('Settings'),
            ],
          ),
        ),
      ],
    );
  }
}

class _ShareButton extends StatelessWidget {
  const _ShareButton();

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.share_outlined),
      onPressed: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Share feature coming soon')),
        );
      },
      tooltip: 'Share',
    );
  }
}

class _BookmarkButton extends StatelessWidget {
  const _BookmarkButton();

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.bookmark_border_outlined),
      onPressed: () {
        HapticFeedback.lightImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Assessment bookmarked')),
        );
      },
      tooltip: 'Bookmark',
    );
  }
}

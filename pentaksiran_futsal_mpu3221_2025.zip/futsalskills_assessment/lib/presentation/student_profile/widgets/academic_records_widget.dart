import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:universal_html/html.dart' as html;

import '../../../core/app_export.dart';

class AcademicRecordsWidget extends StatelessWidget {
  final Map<String, dynamic> academicData;

  const AcademicRecordsWidget({
    super.key,
    required this.academicData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCardHeader(context),
            SizedBox(height: 2.h),
            _buildRecordsList(context),
            SizedBox(height: 2.h),
            _buildExportOptions(context),
          ],
        ),
      ),
    );
  }

  Widget _buildCardHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        CustomIconWidget(
          iconName: 'school',
          color: colorScheme.primary,
          size: 6.w,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Text(
            'Academic Records',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
          decoration: BoxDecoration(
            color: AppTheme.successLight.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
            'Current Semester',
            style: theme.textTheme.labelSmall?.copyWith(
              color: AppTheme.successLight,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRecordsList(BuildContext context) {
    final theme = Theme.of(context);
    final records = academicData["records"] as List<Map<String, dynamic>>? ??
        _getDefaultRecords();

    return Column(
      children:
          records.map((record) => _buildRecordItem(context, record)).toList(),
    );
  }

  Widget _buildRecordItem(BuildContext context, Map<String, dynamic> record) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final assessmentName = record["name"] as String? ?? "";
    final date = record["date"] as String? ?? "";
    final score = record["score"] as int? ?? 0;
    final maxScore = record["maxScore"] as int? ?? 100;
    final grade = record["grade"] as String? ?? "";
    final category = record["category"] as String? ?? "";

    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      assessmentName,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      category,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: _getCategoryColor(category),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                    decoration: BoxDecoration(
                      color: _getGradeColor(grade).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      grade,
                      style: theme.textTheme.labelLarge?.copyWith(
                        color: _getGradeColor(grade),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    '$score/$maxScore',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              CustomIconWidget(
                iconName: 'calendar_today',
                color: colorScheme.onSurfaceVariant,
                size: 4.w,
              ),
              SizedBox(width: 1.w),
              Text(
                date,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              const Spacer(),
              LinearProgressIndicator(
                value: score / maxScore,
                backgroundColor: colorScheme.outline.withValues(alpha: 0.2),
                valueColor:
                    AlwaysStoppedAnimation<Color>(_getGradeColor(grade)),
                minHeight: 4,
              ).expand(flex: 3),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildExportOptions(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Export Options',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        Row(
          children: [
            Expanded(
              child: _buildExportButton(
                context,
                'Assessment Transcript',
                'Download detailed assessment report',
                Icons.description_outlined,
                () => _exportTranscript(context),
              ),
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: _buildExportButton(
                context,
                'Performance Certificate',
                'Generate completion certificate',
                Icons.workspace_premium_outlined,
                () => _exportCertificate(context),
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        _buildExportButton(
          context,
          'Complete Academic Data',
          'Export all personal assessment data (GDPR compliant)',
          Icons.download_outlined,
          () => _exportCompleteData(context),
          fullWidth: true,
        ),
      ],
    );
  }

  Widget _buildExportButton(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
    VoidCallback onTap, {
    bool fullWidth = false,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: fullWidth ? double.infinity : null,
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: colorScheme.primary.withValues(alpha: 0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: colorScheme.primary.withValues(alpha: 0.2),
          ),
        ),
        child: Column(
          crossAxisAlignment:
              fullWidth ? CrossAxisAlignment.start : CrossAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: icon.codePoint.toString(),
              color: colorScheme.primary,
              size: 6.w,
            ),
            SizedBox(height: 1.h),
            Text(
              title,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.primary,
              ),
              textAlign: fullWidth ? TextAlign.start : TextAlign.center,
            ),
            SizedBox(height: 0.5.h),
            Text(
              subtitle,
              style: theme.textTheme.bodySmall?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
              textAlign: fullWidth ? TextAlign.start : TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _exportTranscript(BuildContext context) async {
    try {
      final transcriptData = _generateTranscriptData();
      await _downloadFile(transcriptData, 'futsal_assessment_transcript.csv');

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Assessment transcript downloaded successfully'),
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to download transcript. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _exportCertificate(BuildContext context) async {
    try {
      final certificateData = _generateCertificateData();
      await _downloadFile(certificateData, 'futsal_completion_certificate.txt');

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Completion certificate downloaded successfully'),
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to generate certificate. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _exportCompleteData(BuildContext context) async {
    try {
      final completeData = _generateCompleteDataExport();
      await _downloadFile(completeData, 'futsal_complete_academic_data.json');

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Complete academic data exported successfully'),
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to export data. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _downloadFile(String content, String filename) async {
    if (kIsWeb) {
      final bytes = utf8.encode(content);
      final blob = html.Blob([bytes]);
      final url = html.Url.createObjectUrlFromBlob(blob);
      final anchor = html.AnchorElement(href: url)
        ..setAttribute("download", filename)
        ..click();
      html.Url.revokeObjectUrl(url);
    } else {
      // For mobile platforms, this would typically use path_provider
      // For now, we'll show a success message as the file system implementation
      // would require additional platform-specific handling
    }
  }

  String _generateTranscriptData() {
    final records = academicData["records"] as List<Map<String, dynamic>>? ??
        _getDefaultRecords();
    final csvHeader =
        'Assessment,Category,Date,Score,Max Score,Grade,Percentage\n';
    final csvRows = records.map((record) {
      final name = record["name"] as String? ?? "";
      final category = record["category"] as String? ?? "";
      final date = record["date"] as String? ?? "";
      final score = record["score"] as int? ?? 0;
      final maxScore = record["maxScore"] as int? ?? 100;
      final grade = record["grade"] as String? ?? "";
      final percentage = ((score / maxScore) * 100).toStringAsFixed(1);

      return '$name,$category,$date,$score,$maxScore,$grade,$percentage%';
    }).join('\n');

    return csvHeader + csvRows;
  }

  String _generateCertificateData() {
    final studentName =
        academicData["studentName"] as String? ?? "Ahmad Faiz bin Abdullah";
    final courseCode = academicData["courseCode"] as String? ?? "MPU3421";
    final overallGrade = academicData["overallGrade"] as String? ?? "A-";
    final completionDate = DateTime.now().toString().split(' ')[0];

    return '''
FUTSAL SKILLS ASSESSMENT COMPLETION CERTIFICATE

This is to certify that

$studentName

has successfully completed the Futsal Skills Assessment Course ($courseCode)
with an overall grade of $overallGrade.

Date of Completion: $completionDate

This certificate validates the student's proficiency in:
- Sepakan Leret (Side Kick)
- Hantaran Pendek (Short Pass)  
- Menjaring (Scoring)
- Menjaga Gol (Goalkeeping)
- Undang-Undang (Rules Knowledge)
- Teknik (Technique)

Issued by: FutsalSkills Assessment System
Generated on: ${DateTime.now()}
    ''';
  }

  String _generateCompleteDataExport() {
    final completeData = {
      "exportInfo": {
        "generatedOn": DateTime.now().toIso8601String(),
        "exportType": "Complete Academic Data",
        "dataCompliance": "GDPR Compliant Export"
      },
      "studentInfo": academicData,
      "assessmentRecords": academicData["records"] ?? _getDefaultRecords(),
      "performanceMetrics": {
        "overallGrade": academicData["overallGrade"] ?? "A-",
        "totalAssessments": (academicData["records"] as List?)?.length ?? 6,
        "averageScore": _calculateAverageScore(),
      }
    };

    return jsonEncode(completeData);
  }

  double _calculateAverageScore() {
    final records = academicData["records"] as List<Map<String, dynamic>>? ??
        _getDefaultRecords();
    if (records.isEmpty) return 0.0;

    final totalScore = records.fold<int>(
        0, (sum, record) => sum + (record["score"] as int? ?? 0));
    return totalScore / records.length;
  }

  List<Map<String, dynamic>> _getDefaultRecords() {
    return [
      {
        "name": "Sepakan Leret Assessment",
        "category": "Practical Skills",
        "date": "15/10/2024",
        "score": 88,
        "maxScore": 100,
        "grade": "A-"
      },
      {
        "name": "Hantaran Pendek Evaluation",
        "category": "Practical Skills",
        "date": "22/10/2024",
        "score": 92,
        "maxScore": 100,
        "grade": "A"
      },
      {
        "name": "Menjaring Technique Test",
        "category": "Practical Skills",
        "date": "29/10/2024",
        "score": 85,
        "maxScore": 100,
        "grade": "B+"
      },
      {
        "name": "Menjaga Gol Assessment",
        "category": "Practical Skills",
        "date": "05/11/2024",
        "score": 78,
        "maxScore": 100,
        "grade": "B"
      },
      {
        "name": "Undang-Undang Quiz",
        "category": "Theory",
        "date": "12/11/2024",
        "score": 95,
        "maxScore": 100,
        "grade": "A+"
      },
      {
        "name": "Training Simulation",
        "category": "Simulation",
        "date": "19/11/2024",
        "score": 82,
        "maxScore": 100,
        "grade": "B+"
      },
    ];
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case "practical skills":
        return AppTheme.primaryLight;
      case "theory":
        return AppTheme.secondaryLight;
      case "simulation":
        return AppTheme.accentLight;
      default:
        return AppTheme.warningLight;
    }
  }

  Color _getGradeColor(String grade) {
    switch (grade) {
      case "A+":
      case "A":
        return AppTheme.successLight;
      case "A-":
      case "B+":
        return AppTheme.warningLight;
      case "B":
      case "B-":
        return AppTheme.accentLight;
      default:
        return AppTheme.errorLight;
    }
  }
}

extension ExpandedWidget on Widget {
  Widget expand({int flex = 1}) => Expanded(flex: flex, child: this);
}

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/academic_records_widget.dart';
import './widgets/achievement_badges_widget.dart';
import './widgets/performance_summary_card_widget.dart';
import './widgets/personal_info_card_widget.dart';
import './widgets/profile_header_widget.dart';
import './widgets/quick_actions_widget.dart';
import './widgets/settings_card_widget.dart';

class StudentProfile extends StatefulWidget {
  const StudentProfile({super.key});

  @override
  State<StudentProfile> createState() => _StudentProfileState();
}

class _StudentProfileState extends State<StudentProfile> {
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();

  // Mock student data
  Map<String, dynamic> _studentData = {
    "name": "Ahmad Faiz bin Abdullah",
    "studentId": "2023001234",
    "class": "MPU3421-A",
    "group": "Group 3",
    "overallGrade": "A-",
    "gpa": 3.7,
    "profilePhoto":
        "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  };

  Map<String, dynamic> _personalInfo = {
    "phone": "011-2345678",
    "email": "ahmad.faiz@student.upm.edu.my",
    "address": "No. 123, Jalan Universiti, 43400 Serdang, Selangor",
    "emergencyContact": "Puan Siti Aminah binti Hassan",
    "emergencyPhone": "012-9876543",
  };

  Map<String, dynamic> _performanceData = {
    "overallScore": 85,
    "skills": [
      {"name": "Sepakan Leret", "score": 88, "trend": "up"},
      {"name": "Hantaran Pendek", "score": 92, "trend": "up"},
      {"name": "Menjaring", "score": 85, "trend": "stable"},
      {"name": "Menjaga Gol", "score": 78, "trend": "down"},
      {"name": "Undang-Undang", "score": 95, "trend": "up"},
      {"name": "Teknik", "score": 82, "trend": "stable"},
    ],
  };

  List<Map<String, dynamic>> _achievements = [
    {
      "title": "First Goal",
      "description": "Scored your first goal in assessment",
      "icon": "sports_soccer",
      "category": "skill",
      "earned": true,
      "earnedDate": "15/10/2024",
    },
    {
      "title": "Perfect Pass",
      "description": "Achieved 100% accuracy in passing assessment",
      "icon": "target",
      "category": "skill",
      "earned": true,
      "earnedDate": "22/10/2024",
    },
    {
      "title": "Team Player",
      "description": "Excellent teamwork and communication",
      "icon": "groups",
      "category": "participation",
      "earned": true,
      "earnedDate": "29/10/2024",
    },
    {
      "title": "Rule Master",
      "description": "Perfect score in rules knowledge test",
      "icon": "school",
      "category": "progress",
      "earned": true,
      "earnedDate": "12/11/2024",
    },
    {
      "title": "Goalkeeper Pro",
      "description": "Master goalkeeper techniques",
      "icon": "sports_handball",
      "category": "skill",
      "earned": false,
      "earnedDate": "",
    },
    {
      "title": "Course Champion",
      "description": "Complete all assessments with A grade",
      "icon": "emoji_events",
      "category": "progress",
      "earned": false,
      "earnedDate": "",
    },
  ];

  Map<String, dynamic> _settings = {
    "assessmentNotifications": true,
    "gradeNotifications": true,
    "chatNotifications": false,
    "language": "ms",
    "profileVisibility": true,
    "performanceSharing": false,
    "biometricAuth": true,
  };

  Map<String, dynamic> _academicData = {
    "studentName": "Ahmad Faiz bin Abdullah",
    "courseCode": "MPU3421",
    "overallGrade": "A-",
    "records": [
      {
        "name": "Sepakan Leret Assessment",
        "category": "Practical Skills",
        "date": "15/10/2024",
        "score": 88,
        "maxScore": 100,
        "grade": "A-"
      },
      {
        "name": "Hantaran Pendek Evaluation",
        "category": "Practical Skills",
        "date": "22/10/2024",
        "score": 92,
        "maxScore": 100,
        "grade": "A"
      },
      {
        "name": "Menjaring Technique Test",
        "category": "Practical Skills",
        "date": "29/10/2024",
        "score": 85,
        "maxScore": 100,
        "grade": "B+"
      },
      {
        "name": "Menjaga Gol Assessment",
        "category": "Practical Skills",
        "date": "05/11/2024",
        "score": 78,
        "maxScore": 100,
        "grade": "B"
      },
      {
        "name": "Undang-Undang Quiz",
        "category": "Theory",
        "date": "12/11/2024",
        "score": 95,
        "maxScore": 100,
        "grade": "A+"
      },
      {
        "name": "Training Simulation",
        "category": "Simulation",
        "date": "19/11/2024",
        "score": 82,
        "maxScore": 100,
        "grade": "B+"
      },
    ],
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: const CustomStudentAppBar(
        title: 'My Profile',
      ),
      body: RefreshIndicator(
        key: _refreshIndicatorKey,
        onRefresh: _refreshProfile,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              ProfileHeaderWidget(
                studentData: _studentData,
                onEditPhoto: _handleEditPhoto,
              ),
              SizedBox(height: 2.h),
              PersonalInfoCardWidget(
                personalInfo: _personalInfo,
                onInfoUpdated: _handlePersonalInfoUpdate,
              ),
              PerformanceSummaryCardWidget(
                performanceData: _performanceData,
              ),
              AchievementBadgesWidget(
                achievements: _achievements,
              ),
              SettingsCardWidget(
                settings: _settings,
                onSettingsChanged: _handleSettingsChange,
              ),
              AcademicRecordsWidget(
                academicData: _academicData,
              ),
              QuickActionsWidget(
                onEditProfile: _handleEditProfile,
                onChangePassword: _handleChangePassword,
                onContactSupport: _handleContactSupport,
                onPhotoSelected: _handlePhotoSelected,
              ),
              SizedBox(height: 2.h),
              _buildLogoutSection(context),
              SizedBox(height: 10.h), // Bottom padding for navigation
            ],
          ),
        ),
      ),
      bottomNavigationBar: const CustomStudentBottomBar(
        currentIndex: 2, // Profile tab active
      ),
    );
  }

  Widget _buildLogoutSection(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          onPressed: () => _showLogoutDialog(context),
          icon: CustomIconWidget(
            iconName: 'logout',
            color: AppTheme.errorLight,
            size: 5.w,
          ),
          label: Text(
            'Logout',
            style: theme.textTheme.bodyLarge?.copyWith(
              color: AppTheme.errorLight,
              fontWeight: FontWeight.w600,
            ),
          ),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppTheme.errorLight,
            side: BorderSide(color: AppTheme.errorLight),
            padding: EdgeInsets.symmetric(vertical: 2.h),
          ),
        ),
      ),
    );
  }

  Future<void> _refreshProfile() async {
    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));

    // In a real app, this would fetch updated data from the server
    setState(() {
      // Update with fresh data
      _performanceData["overallScore"] = 87; // Simulate score improvement
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Profile updated successfully'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _handleEditPhoto() {
    // This will trigger the photo selection dialog
    // Implementation is handled in QuickActionsWidget
  }

  void _handlePersonalInfoUpdate(Map<String, dynamic> updatedInfo) {
    setState(() {
      _personalInfo = updatedInfo;
    });
  }

  void _handleSettingsChange(Map<String, dynamic> updatedSettings) {
    setState(() {
      _settings = updatedSettings;
    });
  }

  void _handleEditProfile() {
    // Navigate to detailed profile editing screen
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Edit profile feature coming soon'),
      ),
    );
  }

  void _handleChangePassword() {
    // This is handled in SettingsCardWidget
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Use the settings section to change your password'),
      ),
    );
  }

  void _handleContactSupport() {
    _showSupportDialog(context);
  }

  void _handlePhotoSelected(XFile? photo) {
    if (photo != null) {
      setState(() {
        // In a real app, you would upload the photo and get a URL
        // For now, we'll just show success
        _studentData["profilePhoto"] = photo.path;
      });
    }
  }

  void _showLogoutDialog(BuildContext context) {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'warning',
              color: AppTheme.warningLight,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            const Text('Confirm Logout'),
          ],
        ),
        content: const Text(
          'Are you sure you want to logout? You will need to login again to access your account.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/login-screen',
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorLight,
              foregroundColor: Colors.white,
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  void _showSupportDialog(BuildContext context) {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'support_agent',
              color: AppTheme.primaryLight,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            const Text('Contact Support'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Need help? Contact our support team:'),
            SizedBox(height: 2.h),
            _buildSupportOption(
              context,
              'Email Support',
              'support@futsalskills.edu.my',
              Icons.email_outlined,
            ),
            SizedBox(height: 1.h),
            _buildSupportOption(
              context,
              'Phone Support',
              '+60 3-8946 6000',
              Icons.phone_outlined,
            ),
            SizedBox(height: 1.h),
            _buildSupportOption(
              context,
              'Live Chat',
              'Available 9 AM - 5 PM',
              Icons.chat_outlined,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildSupportOption(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: icon.codePoint.toString(),
            color: colorScheme.primary,
            size: 5.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  subtitle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

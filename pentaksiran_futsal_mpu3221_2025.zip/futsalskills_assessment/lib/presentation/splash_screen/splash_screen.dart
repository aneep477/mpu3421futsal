import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoController;
  late AnimationController _fadeController;
  late Animation<double> _logoScaleAnimation;
  late Animation<double> _fadeAnimation;

  bool _isInitializing = true;
  String _statusMessage = 'Initializing...';

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeApp();
  }

  void _initializeAnimations() {
    // Logo scale animation controller
    _logoController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    // Fade transition controller
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    // Logo scale animation with bounce effect
    _logoScaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoController,
      curve: Curves.elasticOut,
    ));

    // Fade animation for smooth transition
    _fadeAnimation = Tween<double>(
      begin: 1.0,
      end: 0.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));

    // Start logo animation
    _logoController.forward();
  }

  Future<void> _initializeApp() async {
    try {
      // Set system UI overlay style for branded experience
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          systemNavigationBarColor: AppTheme.primaryLight,
          systemNavigationBarIconBrightness: Brightness.light,
        ),
      );

      // Simulate initialization tasks with realistic timing
      await _performInitializationTasks();

      // Wait for minimum splash duration
      await Future.delayed(const Duration(milliseconds: 2500));

      // Start fade out animation
      await _fadeController.forward();

      // Navigate based on app state
      await _navigateToNextScreen();
    } catch (e) {
      _handleInitializationError(e);
    }
  }

  Future<void> _performInitializationTasks() async {
    // Task 1: Check authentication status
    setState(() => _statusMessage = 'Checking authentication...');
    await Future.delayed(const Duration(milliseconds: 500));

    // Task 2: Load user preferences
    setState(() => _statusMessage = 'Loading preferences...');
    await Future.delayed(const Duration(milliseconds: 400));

    // Task 3: Sync offline assessment data
    setState(() => _statusMessage = 'Syncing assessment data...');
    await Future.delayed(const Duration(milliseconds: 600));

    // Task 4: Prepare cached content
    setState(() => _statusMessage = 'Preparing content...');
    await Future.delayed(const Duration(milliseconds: 300));

    setState(() => _statusMessage = 'Ready!');
  }

  Future<void> _navigateToNextScreen() async {
    if (!mounted) return;

    // Simulate authentication check
    final bool isAuthenticated = await _checkAuthenticationStatus();
    final String userRole = await _getUserRole();

    if (isAuthenticated) {
      // Navigate based on user role
      switch (userRole) {
        case 'student':
          Navigator.pushReplacementNamed(context, '/student-dashboard');
          break;
        case 'instructor':
          Navigator.pushReplacementNamed(
              context, '/instructor-assessment-interface');
          break;
        default:
          Navigator.pushReplacementNamed(context, '/student-dashboard');
      }
    } else {
      // Navigate to login for new users
      Navigator.pushReplacementNamed(context, '/login-screen');
    }
  }

  Future<bool> _checkAuthenticationStatus() async {
    // Simulate authentication check
    // In real implementation, check stored tokens/credentials
    await Future.delayed(const Duration(milliseconds: 200));
    return false; // Default to not authenticated for demo
  }

  Future<String> _getUserRole() async {
    // Simulate user role retrieval
    // In real implementation, get from stored user data
    await Future.delayed(const Duration(milliseconds: 100));
    return 'student'; // Default role
  }

  void _handleInitializationError(dynamic error) {
    setState(() {
      _statusMessage = 'Connection timeout';
      _isInitializing = false;
    });

    // Show retry option after 5 seconds
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted) {
        _showRetryDialog();
      }
    });
  }

  void _showRetryDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(
          'Connection Error',
          style: AppTheme.lightTheme.textTheme.titleLarge,
        ),
        content: Text(
          'Unable to initialize the app. Please check your internet connection and try again.',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {
                _isInitializing = true;
                _statusMessage = 'Retrying...';
              });
              _initializeApp();
            },
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _logoController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: _fadeAnimation,
        builder: (context, child) {
          return Opacity(
            opacity: _fadeAnimation.value,
            child: Container(
              width: 100.w,
              height: 100.h,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppTheme.primaryLight,
                    AppTheme.primaryVariantLight,
                    AppTheme.secondaryLight,
                  ],
                  stops: const [0.0, 0.6, 1.0],
                ),
              ),
              child: SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // University/Course Logo Section
                    Expanded(
                      flex: 3,
                      child: Center(
                        child: AnimatedBuilder(
                          animation: _logoScaleAnimation,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: _logoScaleAnimation.value,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  // Main Logo
                                  Container(
                                    width: 35.w,
                                    height: 35.w,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black
                                              .withValues(alpha: 0.2),
                                          blurRadius: 20,
                                          offset: const Offset(0, 10),
                                        ),
                                      ],
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        CustomIconWidget(
                                          iconName: 'sports_soccer',
                                          color: AppTheme.primaryLight,
                                          size: 15.w,
                                        ),
                                        SizedBox(height: 1.h),
                                        Text(
                                          'FS',
                                          style: AppTheme.lightTheme.textTheme
                                              .headlineSmall
                                              ?.copyWith(
                                            color: AppTheme.primaryLight,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 2,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 3.h),
                                  // App Title
                                  Text(
                                    'FutsalSkills',
                                    style: AppTheme
                                        .lightTheme.textTheme.headlineMedium
                                        ?.copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                  SizedBox(height: 1.h),
                                  Text(
                                    'Assessment Platform',
                                    style: AppTheme
                                        .lightTheme.textTheme.titleMedium
                                        ?.copyWith(
                                      color:
                                          Colors.white.withValues(alpha: 0.9),
                                      fontWeight: FontWeight.w400,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  SizedBox(height: 0.5.h),
                                  Text(
                                    'MPU3421',
                                    style: AppTheme
                                        .lightTheme.textTheme.bodyMedium
                                        ?.copyWith(
                                      color:
                                          Colors.white.withValues(alpha: 0.8),
                                      fontWeight: FontWeight.w300,
                                      letterSpacing: 2,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ),

                    // Loading Section
                    Expanded(
                      flex: 1,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Loading Indicator
                          SizedBox(
                            width: 8.w,
                            height: 8.w,
                            child: CircularProgressIndicator(
                              strokeWidth: 3,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Colors.white.withValues(alpha: 0.9),
                              ),
                            ),
                          ),
                          SizedBox(height: 2.h),

                          // Status Message
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 300),
                            child: Text(
                              _statusMessage,
                              key: ValueKey(_statusMessage),
                              style: AppTheme.lightTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: Colors.white.withValues(alpha: 0.8),
                                fontWeight: FontWeight.w400,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Footer Section
                    Padding(
                      padding: EdgeInsets.only(bottom: 4.h),
                      child: Column(
                        children: [
                          Text(
  'IPG KAMPUS DARULAMAN ',
  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
    color: Color(0XB3FFFFFF),
    fontFamily: Inter_regular,
    fontSize: 12,
    fontWeight: FontWeight.w300,
    height: 1.43,
    letterSpacing: 0.4,
    wordSpacing: 0,
  ),
),
                          SizedBox(height: 0.5.h),
                          Text(
                            'Version 1.0.0',
                            style: AppTheme.lightTheme.textTheme.labelSmall
                                ?.copyWith(
                              color: Colors.white.withValues(alpha: 0.6),
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

package com.futsalskills_assessment.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

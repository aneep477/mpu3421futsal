import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class NotificationBanner extends StatelessWidget {
  final Map<String, dynamic>? notification;
  final VoidCallback? onDismiss;
  final VoidCallback? onTap;

  const NotificationBanner({
    super.key,
    this.notification,
    this.onDismiss,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    if (notification == null) return const SizedBox.shrink();

    final type = notification!['type'] as String;
    final title = notification!['title'] as String;
    final message = notification!['message'] as String;
    final isUrgent = notification!['isUrgent'] as bool? ?? false;

    Color backgroundColor;
    Color textColor;
    Color iconColor;
    IconData iconData;

    switch (type) {
      case 'assessment':
        backgroundColor =
            AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1);
        textColor = AppTheme.lightTheme.colorScheme.primary;
        iconColor = AppTheme.lightTheme.colorScheme.primary;
        iconData = Icons.assignment;
        break;
      case 'message':
        backgroundColor =
            AppTheme.lightTheme.colorScheme.tertiary.withValues(alpha: 0.1);
        textColor = AppTheme.lightTheme.colorScheme.tertiary;
        iconColor = AppTheme.lightTheme.colorScheme.tertiary;
        iconData = Icons.message;
        break;
      case 'warning':
        backgroundColor = Colors.orange.withValues(alpha: 0.1);
        textColor = Colors.orange;
        iconColor = Colors.orange;
        iconData = Icons.warning;
        break;
      case 'error':
        backgroundColor =
            AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.1);
        textColor = AppTheme.lightTheme.colorScheme.error;
        iconColor = AppTheme.lightTheme.colorScheme.error;
        iconData = Icons.error;
        break;
      default:
        backgroundColor =
            AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1);
        textColor = AppTheme.lightTheme.colorScheme.primary;
        iconColor = AppTheme.lightTheme.colorScheme.primary;
        iconData = Icons.info;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.lightImpact();
            onTap?.call();
          },
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(12),
              border: isUrgent
                  ? Border.all(
                      color: iconColor.withValues(alpha: 0.3),
                      width: 2,
                    )
                  : Border.all(
                      color: iconColor.withValues(alpha: 0.2),
                      width: 1,
                    ),
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: iconColor.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: CustomIconWidget(
                    iconName: iconData == Icons.assignment
                        ? 'assignment'
                        : iconData == Icons.message
                            ? 'message'
                            : iconData == Icons.warning
                                ? 'warning'
                                : iconData == Icons.error
                                    ? 'error'
                                    : 'info',
                    color: iconColor,
                    size: 20,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              title,
                              style: AppTheme.lightTheme.textTheme.bodyLarge
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: textColor,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (isUrgent) ...[
                            SizedBox(width: 2.w),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 2.w, vertical: 0.5.h),
                              decoration: BoxDecoration(
                                color: AppTheme.lightTheme.colorScheme.error
                                    .withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                'PENTING',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: AppTheme.lightTheme.colorScheme.error,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 10.sp,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        message,
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: textColor.withValues(alpha: 0.8),
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                if (onDismiss != null) ...[
                  SizedBox(width: 2.w),
                  InkWell(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      onDismiss?.call();
                    },
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: EdgeInsets.all(1.w),
                      child: CustomIconWidget(
                        iconName: 'close',
                        color: iconColor.withValues(alpha: 0.6),
                        size: 18,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

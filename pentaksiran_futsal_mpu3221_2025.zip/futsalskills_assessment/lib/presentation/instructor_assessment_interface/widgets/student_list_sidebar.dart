import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class StudentListSidebar extends StatefulWidget {
  final List<Map<String, dynamic>> students;
  final Map<String, dynamic>? selectedStudent;
  final Function(Map<String, dynamic>) onStudentSelected;
  final bool isVisible;
  final VoidCallback onClose;

  const StudentListSidebar({
    super.key,
    required this.students,
    this.selectedStudent,
    required this.onStudentSelected,
    required this.isVisible,
    required this.onClose,
  });

  @override
  State<StudentListSidebar> createState() => _StudentListSidebarState();
}

class _StudentListSidebarState extends State<StudentListSidebar>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _filteredStudents = [];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _filteredStudents = widget.students;
    _searchController.addListener(_filterStudents);
  }

  @override
  void didUpdateWidget(StudentListSidebar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isVisible != oldWidget.isVisible) {
      if (widget.isVisible) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    }
    if (widget.students != oldWidget.students) {
      _filteredStudents = widget.students;
      _filterStudents();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _searchController.removeListener(_filterStudents);
    _searchController.dispose();
    super.dispose();
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(-1.0, 0.0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 0.5,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    if (widget.isVisible) {
      _animationController.forward();
    }
  }

  void _filterStudents() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredStudents = widget.students.where((student) {
        final name = (student["name"] as String? ?? "").toLowerCase();
        final studentId = (student["studentId"] as String? ?? "").toLowerCase();
        final className = (student["class"] as String? ?? "").toLowerCase();
        return name.contains(query) ||
            studentId.contains(query) ||
            className.contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isVisible) return const SizedBox.shrink();

    return Stack(
      children: [
        _buildBackdrop(),
        _buildSidebar(),
      ],
    );
  }

  Widget _buildBackdrop() {
    return AnimatedBuilder(
      animation: _fadeAnimation,
      builder: (context, child) {
        return GestureDetector(
          onTap: widget.onClose,
          child: Container(
            width: double.infinity,
            height: double.infinity,
            color: Colors.black.withValues(alpha: _fadeAnimation.value),
          ),
        );
      },
    );
  }

  Widget _buildSidebar() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return AnimatedBuilder(
      animation: _slideAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(_slideAnimation.value.dx * 80.w, 0),
          child: Container(
            width: 80.w,
            height: double.infinity,
            decoration: BoxDecoration(
              color: colorScheme.surface,
              boxShadow: [
                BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.2),
                  blurRadius: 16,
                  offset: const Offset(4, 0),
                ),
              ],
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildSidebarHeader(context),
                  _buildSearchField(context),
                  Expanded(child: _buildStudentList(context)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSidebarHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.primary.withValues(alpha: 0.1),
        border: Border(
          bottom: BorderSide(
            color: colorScheme.outline.withValues(alpha: 0.2),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'group',
            color: colorScheme.primary,
            size: 6.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Senarai Pelajar",
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onSurface,
                  ),
                ),
                Text(
                  "${_filteredStudents.length} pelajar",
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: widget.onClose,
            icon: CustomIconWidget(
              iconName: 'close',
              color: colorScheme.onSurfaceVariant,
              size: 6.w,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchField(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.all(4.w),
      child: TextField(
        controller: _searchController,
        style: theme.textTheme.bodyMedium?.copyWith(
          color: colorScheme.onSurface,
        ),
        decoration: InputDecoration(
          hintText: "Cari pelajar...",
          hintStyle: theme.textTheme.bodyMedium?.copyWith(
            color: colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
          ),
          prefixIcon: Padding(
            padding: EdgeInsets.all(3.w),
            child: CustomIconWidget(
              iconName: 'search',
              color: colorScheme.onSurfaceVariant,
              size: 5.w,
            ),
          ),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  onPressed: () {
                    _searchController.clear();
                  },
                  icon: CustomIconWidget(
                    iconName: 'clear',
                    color: colorScheme.onSurfaceVariant,
                    size: 5.w,
                  ),
                )
              : null,
          filled: true,
          fillColor: colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        ),
      ),
    );
  }

  Widget _buildStudentList(BuildContext context) {
    if (_filteredStudents.isEmpty) {
      return _buildEmptyState(context);
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 2.w),
      itemCount: _filteredStudents.length,
      itemBuilder: (context, index) {
        final student = _filteredStudents[index];
        return _buildStudentItem(context, student);
      },
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'search_off',
            color: colorScheme.onSurfaceVariant,
            size: 12.w,
          ),
          SizedBox(height: 2.h),
          Text(
            "Tiada pelajar dijumpai",
            style: theme.textTheme.titleMedium?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            "Cuba cari dengan nama atau ID yang berbeza",
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStudentItem(BuildContext context, Map<String, dynamic> student) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isSelected =
        widget.selectedStudent?["studentId"] == student["studentId"];
    final completionStatus =
        student["assessmentStatus"] as String? ?? "pending";

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
      child: InkWell(
        onTap: () {
          HapticFeedback.selectionClick();
          widget.onStudentSelected(student);
          widget.onClose();
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: isSelected
                ? colorScheme.primary.withValues(alpha: 0.1)
                : colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected
                  ? colorScheme.primary
                  : colorScheme.outline.withValues(alpha: 0.2),
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              _buildStudentAvatar(context, student),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildStudentInfo(context, student),
              ),
              _buildStatusIndicator(context, completionStatus),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStudentAvatar(
      BuildContext context, Map<String, dynamic> student) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      width: 12.w,
      height: 12.w,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: ClipOval(
        child: student["photo"] != null
            ? CustomImageWidget(
                imageUrl: student["photo"] as String,
                width: 12.w,
                height: 12.w,
                fit: BoxFit.cover,
              )
            : Container(
                color: colorScheme.surfaceContainerHighest,
                child: CustomIconWidget(
                  iconName: 'person',
                  color: colorScheme.onSurfaceVariant,
                  size: 6.w,
                ),
              ),
      ),
    );
  }

  Widget _buildStudentInfo(BuildContext context, Map<String, dynamic> student) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          student["name"] as String? ?? "Nama Pelajar",
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
            color: colorScheme.onSurface,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        SizedBox(height: 0.5.h),
        Text(
          student["studentId"] as String? ?? "A12345678",
          style: theme.textTheme.bodySmall?.copyWith(
            color: colorScheme.onSurfaceVariant,
          ),
        ),
        Text(
          student["class"] as String? ?? "MPU3421-01",
          style: theme.textTheme.bodySmall?.copyWith(
            color: colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _buildStatusIndicator(BuildContext context, String status) {
    final theme = Theme.of(context);
    Color statusColor;
    String statusIcon;
    String statusText;

    switch (status.toLowerCase()) {
      case 'completed':
        statusColor = Colors.green;
        statusIcon = 'check_circle';
        statusText = 'Selesai';
        break;
      case 'in_progress':
        statusColor = Colors.orange;
        statusIcon = 'schedule';
        statusText = 'Sedang';
        break;
      default:
        statusColor = Colors.grey;
        statusIcon = 'radio_button_unchecked';
        statusText = 'Belum';
        break;
    }

    return Column(
      children: [
        CustomIconWidget(
          iconName: statusIcon,
          color: statusColor,
          size: 5.w,
        ),
        SizedBox(height: 0.5.h),
        Text(
          statusText,
          style: theme.textTheme.labelSmall?.copyWith(
            color: statusColor,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class CourseBrandingWidget extends StatelessWidget {
  const CourseBrandingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildLogo(),
        SizedBox(height: 3.h),
        _buildCourseTitle(),
        SizedBox(height: 1.h),
        _buildCourseSubtitle(),
      ],
    );
  }

  Widget _buildLogo() {
    return Container(
      width: 20.w,
      height: 20.w,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.lightTheme.colorScheme.primary,
            AppTheme.lightTheme.colorScheme.secondary,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color:
                AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: CustomIconWidget(
          iconName: 'sports_soccer',
          color: AppTheme.lightTheme.colorScheme.onPrimary,
          size: 10.w,
        ),
      ),
    );
  }

  Widget _buildCourseTitle() {
    return Text(
      'MPU3421',
      style: AppTheme.lightTheme.textTheme.headlineMedium?.copyWith(
        fontWeight: FontWeight.w700,
        color: AppTheme.lightTheme.colorScheme.primary,
        letterSpacing: 1.2,
      ),
    );
  }

  Widget _buildCourseSubtitle() {
    return Column(
      children: [
        Text(
          'FutsalSkills Assessment',
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          'Sistem Penilaian Kemahiran Futsal',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

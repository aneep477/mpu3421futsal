import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class AssessmentCriteriaSection extends StatefulWidget {
  final Map<String, dynamic> criteriaData;

  const AssessmentCriteriaSection({
    super.key,
    required this.criteriaData,
  });

  @override
  State<AssessmentCriteriaSection> createState() =>
      _AssessmentCriteriaSectionState();
}

class _AssessmentCriteriaSectionState extends State<AssessmentCriteriaSection> {
  int _expandedLevel = -1;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final rubricLevels =
        widget.criteriaData['rubricLevels'] as List<Map<String, dynamic>>? ??
            [];

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(theme),
          SizedBox(height: 2.h),
          _buildRubricDescription(theme),
          SizedBox(height: 3.h),
          ...rubricLevels.asMap().entries.map((entry) {
            final index = entry.key;
            final level = entry.value;
            return _buildRubricLevel(theme, level, index);
          }),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(ThemeData theme) {
    return Row(
      children: [
        CustomIconWidget(
          iconName: 'checklist',
          color: theme.colorScheme.primary,
          size: 20,
        ),
        SizedBox(width: 2.w),
        Text(
          'Kriteria Penilaian',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color: theme.colorScheme.onSurface,
          ),
        ),
      ],
    );
  }

  Widget _buildRubricDescription(ThemeData theme) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.primary.withValues(alpha: 0.1),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Panduan Rubrik Penilaian',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.primary,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            widget.criteriaData['description'] as String? ??
                'Penilaian berdasarkan 5 tahap prestasi dari Pemula (1) hingga Pakar (5). Setiap tahap mempunyai indikator prestasi yang jelas untuk memastikan penilaian yang konsisten dan adil.',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRubricLevel(
      ThemeData theme, Map<String, dynamic> level, int index) {
    final levelNumber = level['level'] as int? ?? (index + 1);
    final isExpanded = _expandedLevel == index;
    final currentLevel = widget.criteriaData['currentLevel'] as int? ?? 0;
    final isAchieved = levelNumber <= currentLevel;
    final isCurrent = levelNumber == currentLevel;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: 2.h),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isCurrent
              ? theme.colorScheme.primary
              : isAchieved
                  ? _getLevelColor(levelNumber).withValues(alpha: 0.3)
                  : theme.colorScheme.outline.withValues(alpha: 0.2),
          width: isCurrent ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.shadow.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() {
              _expandedLevel = isExpanded ? -1 : index;
            }),
            borderRadius: BorderRadius.circular(16),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              child: Row(
                children: [
                  Container(
                    width: 12.w,
                    height: 12.w,
                    decoration: BoxDecoration(
                      color: isAchieved
                          ? _getLevelColor(levelNumber)
                          : theme.colorScheme.outline.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: _getLevelColor(levelNumber),
                        width: isAchieved ? 0 : 2,
                      ),
                    ),
                    child: Center(
                      child: isAchieved
                          ? CustomIconWidget(
                              iconName: 'check',
                              color: Colors.white,
                              size: 16,
                            )
                          : Text(
                              '$levelNumber',
                              style: theme.textTheme.titleSmall?.copyWith(
                                color: _getLevelColor(levelNumber),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              level['title'] as String? ?? 'Tahap $levelNumber',
                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: theme.colorScheme.onSurface,
                              ),
                            ),
                            if (isCurrent) ...[
                              SizedBox(width: 2.w),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 2.w, vertical: 0.5.h),
                                decoration: BoxDecoration(
                                  color: theme.colorScheme.primary,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  'Semasa',
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: theme.colorScheme.onPrimary,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          level['subtitle'] as String? ??
                              _getLevelSubtitle(levelNumber),
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                  CustomIconWidget(
                    iconName: isExpanded ? 'expand_less' : 'expand_more',
                    color: theme.colorScheme.onSurfaceVariant,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded) _buildExpandedContent(theme, level),
        ],
      ),
    );
  }

  Widget _buildExpandedContent(ThemeData theme, Map<String, dynamic> level) {
    final indicators = level['indicators'] as List<String>? ?? [];

    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(4.w, 0, 4.w, 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Divider(
            color: theme.colorScheme.outline.withValues(alpha: 0.2),
            height: 2.h,
          ),
          Text(
            'Indikator Prestasi:',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.h),
          ...indicators.map((indicator) => Padding(
                padding: EdgeInsets.only(bottom: 1.h),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      margin: EdgeInsets.only(top: 1.h, right: 3.w),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary,
                        shape: BoxShape.circle,
                      ),
                    ),
                    Expanded(
                      child: Text(
                        indicator,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurface,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Color _getLevelColor(int level) {
    switch (level) {
      case 1:
        return Colors.red;
      case 2:
        return Colors.orange;
      case 3:
        return Colors.amber;
      case 4:
        return Colors.lightGreen;
      case 5:
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getLevelSubtitle(int level) {
    switch (level) {
      case 1:
        return 'Pemula - Memerlukan bimbingan penuh';
      case 2:
        return 'Berkembang - Memerlukan sedikit bimbingan';
      case 3:
        return 'Cekap - Boleh melakukan secara bebas';
      case 4:
        return 'Mahir - Prestasi yang konsisten';
      case 5:
        return 'Pakar - Prestasi cemerlang dan boleh membimbing';
      default:
        return 'Tahap prestasi';
    }
  }
}
